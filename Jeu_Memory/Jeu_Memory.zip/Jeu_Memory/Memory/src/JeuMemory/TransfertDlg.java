/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JDialog.java to edit this template
 */
package JeuMemory;

import JeuMemory.LesJoueurs;
import java.awt.Dimension;
import java.awt.Image;
import java.awt.List;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;

/**
 *
 * @author Brice
 */
public class TransfertDlg extends javax.swing.JDialog {

    /**
     * Creates new form TransfertDlg
    */
     private LesJoueurs lj; //collection des joueurs, pour initialiser la liste déroulante avec les pseudos des joueurs
     private int indj; //indice joueur courant
     // private Transfert tc; // cette classe sera étudiée ultérieurement – laisser l’attribut en commentaire
     private boolean ok; // indicateur pour savoir le transfert a bien été effectué.
     private int indjs; //indice du joueur sélectionné dans la liste déroulante
     private String fs; //famille du personnage sélectionné en cliquant sur un des personnages du joueur sélectionné

    public boolean isOk() {
        return ok;
    }
    
    public void setOk(boolean b){
        this.ok = b;
    }
     
     

    public TransfertDlg(java.awt.Frame parent, boolean modal,  LesJoueurs lj, int indj) {
        super(parent, modal);
        initComponents();
        this.lj = lj;
        this.indj = indj ;
        // this.tc=null;
        this.ok=false;
        this.fs=null;
        initCombo(); // méthode pour remplir la liste déroulante
        indjs = 0;
        Message.setText("Le joueur "+lj.getJoueur(indj).getPseudo()+" a obtenu une famille complète");
        Message1.setText("Il peut prendre toutes les cartes d'une même famille d'un joueur");
        Message2.setText("Selectionnez le joueur dont vous voulez voir les cartes");
        Infos.setText("Personnages de "+lj.getJoueur(indj).getPseudo()+" : \n"+lj.getJoueur(indj).getPaquet());
        initPanneauDroit();
    }
    
        public void initCombo() {
            ComboJoueurs.removeAllItems(); // Supprime tous les éléments de la liste déroulante
            for (int i = 0; i < lj.getNbJoueurs(); i++) { // Parcours de tous les joueurs
                ComboJoueurs.addItem(lj.getJoueur(i).getPseudo()); // Ajoute le pseudo du joueur à la liste déroulante
        }
    }
    
    public void initPanneauG() {
    // Supprime tous les composants du panneau PanneauG
    PanneauG.removeAll();
    
    // Ré-affiche la boîte de dialogue
    this.repaint();
    
    // Récupère les personnages du paquet du joueur sélectionné dans une variable lcs de type LesPersonnages
    LesPersonnages lcs = lj.getJoueur(indjs).getPaquet();
    
    // Initialise la disposition du panneau PanneauG en fonction du nombre de personnages qu'il possède
    int t = lcs.getTaille(); // Nombre total de personnages
    int n = 1 + (t - 1) / 4; // Nombre de colonnes dans la disposition (4 boutons par ligne)
    PanneauG.setLayout(new java.awt.GridLayout(4, n));
    
    // Boucle pour créer et ajouter les boutons correspondant à chaque personnage au panneau PanneauG
    for (int i = 0; i < t; i++) {
        JButton bt = new JButton();
        bt.setName(lcs.getPerso(i).getFamille()); // Le nom du bouton est la famille du personnage
        bt.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent evt) {
                boutonActionPerformed(evt);
                
            }
        }); // Ajoute un écouteur d'action pour exécuter le gestionnaire boutonActionPerformed(evt)
        PanneauG.add(bt); // Ajoute le bouton au panneau PanneauG
    }
    
    // Appelle la méthode pack() pour ajuster la taille de la boîte de dialogue en fonction de son contenu
    this.pack();
  
    }
    
     
/**
 * Initialise le panneau droit avec les boutons représentant les personnages du joueur courant.
 */
    private void initPanneauDroit(){
        // Supprime tous les composants actuellement présents dans le panneau droit
        PanneauD.removeAll();
        // Redessine le panneau
        this.repaint();
    
        // Récupère le paquet de personnages du joueur courant
        LesPersonnages lcs = lj.getJoueur(indj).getPaquet();
        // Obtient le nombre total de personnages dans le paquet
        int t = lcs.getTaille();
        // Calcule le nombre de colonnes nécessaire pour afficher les boutons
        int n = 1 + (t - 1) / 4;
    
        // Définit la disposition du panneau avec un nombre de lignes dynamique et n colonnes
        PanneauD.setLayout(new java.awt.GridLayout(0, n));
    
        // Calcule la taille des boutons en fonction de la largeur du panneau droit
        int buttonSize = this.getWidth() / (3 * n);
    
        // Boucle pour créer et ajouter les boutons représentant chaque personnage
        for(int i = 0; i < t; i++){
            JButton bt = new JButton();
            // Définit la taille préférée de chaque bouton pour garantir une disposition correcte
            bt.setPreferredSize(new Dimension(buttonSize, buttonSize));
            // Donne au bouton le nom de la famille du personnage pour une identification ultérieure
            bt.setName(lcs.getPerso(i).getFamille());
            // Ajoute un écouteur d'événement pour gérer les clics sur les boutons
            bt.addActionListener(new ActionListener(){
            @Override
            public void actionPerformed(ActionEvent e) {
                boutonActionPerformed(e); // Appelle la méthode pour gérer l'événement du bouton
                }                
            });
            // Ajoute le bouton au panneau droit
            PanneauD.add(bt);
        }
    
        // Ajuste la taille de la boîte de dialogue en fonction de son contenu
        this.pack();
        // Dessine les personnages sur le panneau droit
        dessinePanneau(PanneauD, lj.getJoueur(indj).getPaquet());
    }
    
    
    // Méthode pour dessiner le panneau avec les personnages
    public void dessinePanneau(JPanel jp, LesPersonnages lc) {
        int size = lc.getTaille();
        for (int i = 0; i < size; i++) {
            JButton currentButton = (JButton) jp.getComponent(i); // Récupère le bouton actuel du panneau
            if (i < lc.getPersos().size()) { // Vérifie s'il y a un personnage à cet index
                Personnage personnage = lc.getPersos().get(i); // Récupère le personnage correspondant à l'index
                Image photo = personnage.getPhoto(); // Récupère la photo du personnage
        
                // Redimensionne l'image pour qu'elle occupe tout le bouton
                Image scaledImage = photo.getScaledInstance(currentButton.getWidth(), currentButton.getHeight(), Image.SCALE_SMOOTH);
                currentButton.setIcon(new ImageIcon(scaledImage)); // Définit l'icône du bouton comme étant la photo redimensionnée
                currentButton.setText(personnage.getNom()); // Ajoute le nom du personnage comme texte du bouton
                currentButton.setVisible(true); // Rend le bouton visible
            } else {
                currentButton.setIcon(null); // Efface l'icône du bouton s'il n'y a pas de personnage à cet index
                currentButton.setText(""); // Efface le texte du bouton
                currentButton.setVisible(false); // Rend le bouton invisible
            }
        }
    }
    
    
 /**
 * Gère l'événement déclenché lorsqu'un bouton représentant un personnage est cliqué.
 * @param evt L'événement d'action associé au clic sur le bouton.
 */
    private void boutonActionPerformed(ActionEvent evt){
        // Récupère le paquet de personnages du joueur sélectionné dans la liste déroulante
        LesPersonnages lp = lj.getJoueur(indjs).getPaquet();
        // Obtient le nombre total de personnages dans le paquet
        int t = lp.getTaille();
        // Récupère le bouton sur lequel l'utilisateur a cliqué
        JButton bt = (JButton) evt.getSource();
        // Récupère le nom de la famille du personnage associé au bouton cliqué
        fs = bt.getName(); // La propriété Name contient ici le nom du personnage affiché sur le bouton
    
        // Parcourt tous les boutons du panneau gauche
        for(int i = 0; i < t; i++) {
            JButton b = (JButton) (PanneauG.getComponent(i));
            // Si le nom du personnage associé au bouton correspond à celui du bouton cliqué
            if (b.getName().equals(fs))
                // Met en surbrillance le bouton du panneau gauche associé à ce personnage
                b.setBorder(BorderFactory.createMatteBorder(10, 10, 10, 10, new java.awt.Color(255, 0, 0)));
            else
                // Sinon, supprime toute surbrillance des autres boutons
                b.setBorder(null);
        }
    
        // Récupère tous les personnages de la même famille que celui du bouton cliqué
        LesPersonnages lps = lp.getPersosFamille(fs);
        // Met à jour le champ d'informations avec le nombre de personnages récupérables et leurs détails
        Infos.setText("Vous pouvez récupérer " + lps.getTaille() + " personnages : \n" + lps);
    }
    
    public void affichePanneauG() {
    // Récupère le nombre total de personnages dans le paquet du joueur sélectionné
    int nbPersonnages = lj.getJoueur(indjs).getPaquet().getTaille();

    // Boucle à travers chaque bouton dans le panneau PanneauG
        for (int i = 0; i < nbPersonnages; i++) {
    // Récupère le bouton à l'indice i dans le panneau PanneauG
    JButton bouton = (JButton) PanneauG.getComponent(i);

    // Récupère le personnage correspondant à ce bouton dans le paquet du joueur sélectionné
    Personnage personnage = lj.getJoueur(indjs).getPaquet().getPerso(i);

    // Récupère l'image du personnage
    Image photo = personnage.getPhoto();
    
    // Redimensionne l'image pour qu'elle occupe tout le bouton
    Image scaledImage = photo.getScaledInstance(bouton.getWidth(), bouton.getHeight(), Image.SCALE_SMOOTH);
    
    // Ajoute l'image redimensionnée au bouton comme une icône
    bouton.setIcon(new ImageIcon(scaledImage));
}
    }
    
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        PanneauG = new javax.swing.JPanel();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        Message = new javax.swing.JLabel();
        Message1 = new javax.swing.JLabel();
        Message2 = new javax.swing.JLabel();
        ComboJoueurs = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        Infos = new javax.swing.JTextArea();
        jPanel4 = new javax.swing.JPanel();
        BouttonTransfert = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        PanneauD = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        getContentPane().setLayout(new java.awt.GridLayout(1, 3));

        PanneauG.setLayout(new java.awt.GridLayout(1, 0));
        getContentPane().add(PanneauG);

        jPanel1.setLayout(new java.awt.BorderLayout());

        jPanel2.setLayout(new java.awt.GridLayout(2, 0));

        jPanel3.setLayout(new java.awt.GridLayout(4, 0));
        jPanel3.add(Message);
        jPanel3.add(Message1);
        jPanel3.add(Message2);

        ComboJoueurs.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        ComboJoueurs.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ComboJoueursActionPerformed(evt);
            }
        });
        jPanel3.add(ComboJoueurs);

        jPanel2.add(jPanel3);

        Infos.setColumns(20);
        Infos.setRows(5);
        jScrollPane1.setViewportView(Infos);

        jPanel2.add(jScrollPane1);

        jPanel1.add(jPanel2, java.awt.BorderLayout.CENTER);

        jPanel4.setLayout(new java.awt.GridLayout(1, 2));

        BouttonTransfert.setText("Transfert");
        BouttonTransfert.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BouttonTransfertActionPerformed(evt);
            }
        });
        jPanel4.add(BouttonTransfert);

        jButton2.setText("Fermer");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel4.add(jButton2);

        jPanel1.add(jPanel4, java.awt.BorderLayout.SOUTH);

        getContentPane().add(jPanel1);

        javax.swing.GroupLayout PanneauDLayout = new javax.swing.GroupLayout(PanneauD);
        PanneauD.setLayout(PanneauDLayout);
        PanneauDLayout.setHorizontalGroup(
            PanneauDLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 164, Short.MAX_VALUE)
        );
        PanneauDLayout.setVerticalGroup(
            PanneauDLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        getContentPane().add(PanneauD);

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void ComboJoueursActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ComboJoueursActionPerformed
    // Récupère l'indice du joueur sélectionné dans la liste déroulante
    this.indjs = ComboJoueurs.getSelectedIndex();
    if (indjs != -1) { // Vérifie si un joueur a été sélectionné
        if (this.indjs == this.indj) { // Vérifie si le joueur sélectionné est le joueur courant
            Infos.setText("Sélectionnez un joueur différent du joueur courant !"); // Affiche un message d'avertissement
            PanneauG.removeAll(); // Supprime tous les éléments du panneau gauche
            PanneauG.repaint(); // Redessine le panneau gauche
        } else {
            Infos.setText("\nJoueur sélectionné: " + lj.getJoueur(indjs).toString()); // Affiche le pseudo du joueur sélectionné
            initPanneauG(); // Initialise le panneau avec les caractéristiques du joueur sélectionné
            affichePanneauG(); // Affiche le panneau avec les nouvelles caractéristiques
        }
    }
    }//GEN-LAST:event_ComboJoueursActionPerformed
/**
 * Effectue le transfert de cartes entre le joueur courant et le joueur cible.
 * Affiche le résultat du transfert dans la boîte de dialogue.
 */
    private void BouttonTransfertActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BouttonTransfertActionPerformed
    // Récupère le joueur courant et le joueur cible à partir de leurs indices respectifs
    Joueur jCourant = lj.getJoueur(indj);
    Joueur jCible = lj.getJoueur(indjs);
    
    // Crée une instance de la classe Transfert avec les joueurs impliqués et la famille sélectionnée
    Transfert transfert = new Transfert(jCourant, jCible, fs);
    
    // Exécute le transfert et obtient le résultat
    int result = transfert.execute();
    System.out.println(result);
    
    // Si le transfert a été effectué avec succès (c'est-à-dire s'il y a eu des cartes transférées)
    if (result > 0) {
        // Définit le statut de transfert comme réussi
        this.setOk(true);
        // Met à jour les panneaux gauche et droit pour refléter les changements
        initPanneauG();
        affichePanneauG();
        initPanneauDroit();
        // Désactive le bouton de transfert pour empêcher les transferts multiples
        BouttonTransfert.setEnabled(false);
        // Affiche les paquets de cartes mis à jour des joueurs courant et cible dans la console
        System.out.println(jCourant.getPaquet().toString());
        System.out.println(jCible.getPaquet().toString());
        // Ajoute le déroulement du transfert à la boîte de dialogue
        Infos.append(transfert.getDeroulement() + "\n\n");
    } else {
        // Sinon, affiche un message indiquant qu'il est nécessaire de sélectionner un joueur avec au moins une carte
        Infos.append("Il est nécessaire de sélectionner un joueur qui a au moins une carte\n\n");
    }
    }//GEN-LAST:event_BouttonTransfertActionPerformed
/**
 * Cache la fenêtre et libère les ressources associées à celle-ci.
 */
    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        this.setVisible(false);
        this.dispose();
    }//GEN-LAST:event_jButton2ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(TransfertDlg.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(TransfertDlg.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(TransfertDlg.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(TransfertDlg.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the dialog */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                TransfertDlg dialog = new TransfertDlg(new javax.swing.JFrame(), true, null,0);
                dialog.addWindowListener(new java.awt.event.WindowAdapter() {
                    @Override
                    public void windowClosing(java.awt.event.WindowEvent e) {
                        System.exit(0);
                    }
                });
                dialog.setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BouttonTransfert;
    private javax.swing.JComboBox<String> ComboJoueurs;
    private javax.swing.JTextArea Infos;
    private javax.swing.JLabel Message;
    private javax.swing.JLabel Message1;
    private javax.swing.JLabel Message2;
    private javax.swing.JPanel PanneauD;
    private javax.swing.JPanel PanneauG;
    private javax.swing.JButton jButton2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
