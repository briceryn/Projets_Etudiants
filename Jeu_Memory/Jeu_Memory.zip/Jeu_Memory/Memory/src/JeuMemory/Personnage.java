/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package JeuMemory;
import java.awt.* ;
import javax.swing.* ;


/**
 *
 * @author Brice
 */
public class Personnage {
    // Attributs
    private String famille; // Famille du personnage
    private String nom; // Nom du personnage
    private int valeur; // Valeur du personnage
    private Image photo; // Image du personnage
    private Famille f; // Famille du personnage représentée par un objet Famille

    // Constructeur par défaut
    public Personnage() {
        this.famille = "anonyme";
        this.nom = "anonyme";
        this.valeur = 0;
        // Charger l'image par défaut
        this.photo = new ImageIcon(getClass().getResource("/memory/img/anonyme.png")).getImage();
    }

    // Constructeur avec paramètres (famille, nom, valeur)
    public Personnage(String famille, String nom, int valeur) {
        this.famille = famille;
        this.nom = nom;
        this.valeur = valeur;
        this.photo = new ImageIcon(getClass().getResource("/memory/img/anonyme.png")).getImage();
    }

    // Constructeur avec paramètres incluant l'image
    public Personnage(String famille, String nom, int valeur, String img) {
        this.famille = famille;
        this.nom = nom;
        this.valeur = valeur;
        // Charger l'image spécifiée
        this.photo = new ImageIcon(getClass().getResource(img)).getImage();
    }

    // Getter pour la famille
    public String getFamille() {
        return famille;
    }

    // Setter pour la famille
    public void setFamille(String famille) {
        this.famille = famille;
    }

    // Getter pour le nom
    public String getNom() {
        return nom;
    }

    // Setter pour le nom
    public void setNom(String nom) {
        this.nom = nom;
    }

    // Getter pour la valeur
    public int getValeur() {
        return valeur;
    }

    // Setter pour la valeur
    public void setValeur(int valeur) {
        this.valeur = valeur;
    }

    // Getter pour l'image
    public Image getPhoto() {
        return photo;
    }

    // Setter pour l'image
    public void setPhoto(Image photo) {
        this.photo = photo;
    }
    
    // Setter pour la famille (par chaîne de caractères)
    public void setF(String f) {
        // Création d'une nouvelle instance de Famille en fonction de la chaîne passée en paramètre
        switch (f) {
            case "communs": {
                this.f = new Famille("communs", 4);
                break;
            }
            case "rares": {
                this.f = new Famille("rares", 4);
                break;
            }
            case "alpins-femmes": {
                this.f = new Famille("alpins-femmes", 10);
                break;
            }
            case "epiques": {
                this.f = new Famille("epiques", 18);
                break;
            }
            case "legendaires": {
                this.f = new Famille("legendaires", 18);
                break;
            }
            case "as-des-pistes": {
                this.f = new Famille("as-des-pistes", 18);
                break;
            }
            default :{
                System.out.println("Nom de famille invalide");
            }
        }
    }

    // Getter pour la famille
    public Famille getF() {
        return this.f;
    }

    // Méthode toString pour afficher les informations du personnage
    @Override
    public String toString() {
        return "Nom: " + nom + ", Famille: " + famille + ", Valeur: " + valeur;
    }
}