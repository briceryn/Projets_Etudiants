/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package JeuMemory;
import java.util.ArrayList;

/**
 *
 * @author Brice
 */
public class LesJoueurs {
    // Liste des joueurs
    private ArrayList<Joueur> lstj;
    
    // Constructeur par défaut qui initialise la liste des joueurs
    public LesJoueurs(){
        this.lstj = new ArrayList<Joueur>();
    }
    
    // Méthode pour obtenir un joueur à partir de son indice dans la liste
    public Joueur getJoueur(int i){
        return lstj.get(i);
    }
    
    // Méthode pour obtenir l'indice d'un joueur dans la liste
    public int getIndiceJoueur(Joueur j){
        return this.lstj.indexOf(j);
    }
    
    // Méthode pour obtenir le nombre de joueurs dans la liste
    public int getNbJoueurs() {
        return this.lstj.size();
    }
    
    // Méthode pour ajouter un joueur à la liste
    public void ajouteJoueur(Joueur j) {
        if(rechJoueur(j.getPseudo())==null)
            this.lstj.add(j);
        else 
            System.out.println("Joueur déja ajouté");        
    }
    
    // Méthode pour rechercher un joueur par son pseudo
    public Joueur rechJoueur(String p) {
        int i = 0; 
        boolean trouve = false;
        while (i < getNbJoueurs() && !trouve) {
            if (getJoueur(i).getPseudo().equals(p)) {
                trouve = true;
                return getJoueur(i);
            }
            i++; // Incrémenter i à chaque itération
        }
        // Si aucun joueur n'est trouvé, retourner null après la boucle
        return null;
    }
    
    // Méthode pour supprimer un joueur de la liste
    public void supprimeJoueur(Joueur j){
        int i = 0; 
        boolean trouve = false;
        while(i < getNbJoueurs() && !trouve) {
            if (getJoueur(i).getPseudo().equals(j.getPseudo())){
                this.lstj.remove(i);  
                trouve = true;
            }
            else i++;
        }      
    }
    
    // Méthode pour supprimer tous les joueurs de la liste
    public void supprimetousJoueur(){
        for(int i = 0; i < lstj.size(); i++){
            lstj.get(i).Supprime();    
        }
    }
    
    // Méthode pour obtenir les joueurs gagnants (ceux ayant le score le plus élevé)
    public LesJoueurs getGagnant() {
        int maxPoint = 0;
        LesJoueurs gagnant = new LesJoueurs();
        for (int i = 0; i < lstj.size(); i++) {
            Joueur currentPlayer = lstj.get(i);
            int joueurPoint = currentPlayer.getPaquet().getScore();

            if (joueurPoint >= maxPoint) {
                if (joueurPoint > maxPoint) {
                    gagnant = new LesJoueurs();
                    maxPoint = joueurPoint;
                }
                gagnant.ajouteJoueur(currentPlayer);
            }
        }
        return gagnant;
    }
    
    // Méthode pour obtenir une représentation textuelle de la liste des joueurs
    public String toString(){
        String toReturn = "";
        for(int i = 0; i < lstj.size(); i++){
            toReturn += "Joueur " + i + "{" + lstj.get(i).toString() + "}\n";
        }
        return toReturn;
    }
}
