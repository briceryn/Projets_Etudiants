/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package JeuMemory;

import javax.swing.ImageIcon;

/**
 *
 * @author Brice
 */
public class Joueur {
    private String pseudo; // Pseudo du joueur
    private String fp; // Famille préférée du joueur
    private LesPersonnages paquet; // Paquet de personnages du joueur
    private ImageIcon Photo; // Photo du joueur
    private Famille famillepref; // Famille préférée du joueur

    // Constantes pour le nombre maximum de personnages de chaque type
    private static int nbMaxCommuns = 20;
    private static int nbMaxRares = 15;
    private static int nbMaxLegendaires = 10;
    private static int nbMaxEpiques = 5;

    /**
     * Constructeur par défaut.
     * Initialise le joueur avec des valeurs par défaut.
     */
    public Joueur() {
        this.pseudo = "Anonyme";
        this.fp = "Anonyme";
        paquet = new LesPersonnages();
        Photo = new ImageIcon();
    }

    /**
     * Constructeur avec paramètres.
     * Initialise le joueur avec les paramètres spécifiés.
     * @param pseudo Le pseudo du joueur.
     * @param imgJoueur L'image du joueur.
     * @param famille La famille préférée du joueur.
     */
    public Joueur(String pseudo, ImageIcon imgJoueur, String famille) {
        setPseudo(pseudo);
        if (imgJoueur != null) {
            setPhoto(imgJoueur);
        } else {
            setPhoto(new ImageIcon(getClass().getResource("/jeumemory/img/joueurDefaut.jpg")));
        }
        setPaquet(new LesPersonnages());
        if (famille != null) {
            setFp(famille);
        } else {
            setFamillepref(Famille.communs);
        }
    }

    /**
     * Constructeur avec paramètres.
     * Initialise le joueur avec les paramètres spécifiés.
     * @param p Le pseudo du joueur.
     * @param f La famille préférée du joueur.
     */
    public Joueur(String p, String f) {
        this.setPseudo(p);
        this.setFp(f);
        paquet = new LesPersonnages();
        Photo = new ImageIcon();
        this.setFp(f);
    }

    /**
     * Constructeur avec paramètres.
     * Initialise le joueur avec les paramètres spécifiés.
     * @param p Le pseudo du joueur.
     * @param f La famille préférée du joueur.
     */
    public Joueur(String p, Famille f) {
        this(p, f.getNom());
    }

    /**
     * Obtient le pseudo du joueur.
     * @return Le pseudo du joueur.
     */
    public String getPseudo() {
        return this.pseudo;
    }

    /**
     * Définit le pseudo du joueur.
     * @param p Le pseudo à définir.
     */
    public void setPseudo(String p) {
        this.pseudo = p;
    }

    /**
     * Obtient la famille préférée du joueur.
     * @return La famille préférée du joueur.
     */
    public String getFp() {
        return this.fp;
    }

    /**
     * Définit la famille préférée du joueur.
     * @param f La famille à définir.
     */
    public void setFp(String f) {
        this.fp = f;
    }

    /**
     * Définit la famille préférée du joueur à partir de l'objet Famille.
     * @param f La famille à définir.
     */
    public void setFp(Famille f) {
        this.fp = f.getNom();
    }

    /**
     * Obtient la famille préférée du joueur.
     * @return La famille préférée du joueur.
     */
    public Famille getFamillepref() {
        return famillepref;
    }

    /**
     * Définit la famille préférée du joueur.
     * @param f La famille à définir.
     */
    public void setFamillepref(Famille f) {
        switch (f.getNom()) {
            case "communs": {
                this.famillepref = new Famille("communs", 4);
                break;
            }
            case "rares": {
                this.famillepref = new Famille("rares", 4);
                break;
            }
            case "alpins-femmes": {
                this.famillepref = new Famille("alpins-femmes", 10);
                break;
            }
            case "epiques": {
                this.famillepref = new Famille("epiques", 18);
                break;
            }
            case "legendaires": {
                this.famillepref = new Famille("legendaires", 18);
                break;
            }
            case "as-des-pistes": {
                this.famillepref = new Famille("as-des-pistes", 18);
                break;
            }
        }
    }

    /**
     * Obtient le paquet de personnages du joueur.
     * @return Le paquet de personnages du joueur.
     */
    public LesPersonnages getPaquet() {
        return this.paquet;
    }

    /**
     * Définit le paquet de personnages du joueur.
     * @param paquet Le paquet à définir.
     */
    public void setPaquet(LesPersonnages paquet) {
        this.paquet = paquet;
    }

    /**
     * Obtient la photo du joueur.
     * @return La photo du joueur.
     */
    public ImageIcon getPhoto() {
        return this.Photo;
    }

    /**
     * Définit la photo du joueur.
     * @param photo La photo à définir.
     */
    public void setPhoto(ImageIcon photo) {
        this.Photo = photo;
    }

    /**
     * Ajoute un personnage au paquet du joueur.
     * @param p Le personnage à ajouter.
     */
    public void ajoutePersoPaquet(Personnage p) {
        this.paquet.ajoutePerso(p);
    }

    /**
     * Initialise le paquet de personnages avec des personnages de test.
     */
    public void initPaquetTest() {
        ajoutePersoPaquet(new Personnage("communs", "assault-trooper", 10));
        ajoutePersoPaquet(new Personnage("communs", "commando", 20));
        ajoutePersoPaquet(new Personnage("rares", "absolute-zero", 10));
    }

    /**
     * Vérifie si le joueur est valide par rapport à la difficulté spécifiée.
     * @param chosenDifficulty La difficulté choisie.
     * @return true si le joueur est valide pour la difficulté spécifiée, sinon false.
     */
    public boolean isPlayerValidCompareToDifficulty(int chosenDifficulty) {
        if (famillepref.getDifficulty() <= chosenDifficulty) {
            return true;
        }
        return false;
    }

    /**
     * Vérifie si deux joueurs sont égaux.
     * @param j Le joueur à comparer.
     * @return true si les joueurs sont égaux, sinon false.
     */
    public boolean equals(Joueur j) {
        return j.getPseudo().equals(this.pseudo)
               && j.getFamillepref().equals(this.famillepref)
               && j.getPaquet().equals(this.getPaquet())
               && j.getScore() == this.getScore()
               && j.getPhoto().equals(this.getPhoto());
    }

    /**
     * Supprime tous les personnages du paquet du joueur.
     */
    public void Supprime() {
        paquet = new LesPersonnages();
    }

    // Méthodes pour obtenir les nombres maximum de personnages de chaque type
    public int getNbMaxCommuns() {
        return nbMaxCommuns;
    }

    public int getNbMaxRares() {
        return nbMaxRares;
    }

    public int getNbMaxLegendaires() {
        return nbMaxLegendaires;
    }

    public int getNbMaxEpiques() {
        return nbMaxEpiques;
    }

    /**
     * Obtient le nombre de personnages de chaque famille dans le paquet du joueur.
     * @return Un tableau d'entiers contenant le nombre de personnages de chaque famille.
     */
    public int[] getNbPersoFamille() {
        int[] nbPersoFamille = new int[4];
        nbPersoFamille[0] = paquet.getPersosFamille("communs").getTaille();
        nbPersoFamille[1] = paquet.getPersosFamille("rares").getTaille();
        nbPersoFamille[2] = paquet.getPersosFamille("legendaires").getTaille();
        nbPersoFamille[3] = paquet.getPersosFamille("epiques").getTaille();
        return nbPersoFamille;
    }

    /**
     * Obtient le score total du joueur.
     * @return Le score total du joueur.
     */
    public int getScore() {
        return getPaquet().getScore();
    }

    /**
     * Obtient une représentation textuelle du joueur.
     * @return Une chaîne de caractères représentant le joueur.
     */
    public String toString() {
        return "Joueur " + this.getPseudo() + "\n" + "Famille préférée : " + this.getFp()
               + "\n" + "en possession des personnages :" + this.getPaquet() + "\n" + "Score :" + this.getScore();
    }
}