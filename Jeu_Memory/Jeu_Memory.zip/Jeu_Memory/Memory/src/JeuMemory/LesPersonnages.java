/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package JeuMemory;
import java.util.ArrayList;
/**
 *
 * @author Brice
 */
public class LesPersonnages {
    // Attribut
    private ArrayList<Personnage> persos; // Liste des personnages
    
    // Getter pour la liste des personnages
    public ArrayList<Personnage> getPersos() {
        return persos;
    }
    
    // Constructeur par défaut
    public LesPersonnages() {
        // Initialisation de la liste des personnages
        this.persos = new ArrayList<Personnage>();
    }
         
    // Méthode pour obtenir la taille de la liste des personnages
    public int getTaille() { 
        return this.persos.size(); 
    }
     
    // Méthode pour calculer le score total des personnages dans la liste
    public int getScore() {   
        int sc = 0;
        // Parcours de tous les personnages dans la liste
        for(int i = 0; i < getTaille(); i++)
            sc += getPerso(i).getValeur(); // Ajout de la valeur du personnage au score total
        return sc;
    }
          
    // Méthode pour obtenir un personnage à partir de son index dans la liste
    public Personnage getPerso(int i) {
        // Vérification si l'index est valide
        if (i >= 0 && i < this.persos.size())
            return this.persos.get(i); // Retourne le personnage à l'index spécifié
        else 
            return null; // Retourne null si l'index est invalide
    }
    
    // Méthode pour obtenir une sous-liste de personnages appartenant à une famille spécifique
    public LesPersonnages getPersosFamille(String f) {
        LesPersonnages lp = new LesPersonnages(); // Création d'une nouvelle liste pour stocker les personnages de la famille spécifique
        // Parcours de tous les personnages dans la liste actuelle
        for(int i = 0; i < getTaille(); i++)
            // Vérification si le personnage appartient à la famille spécifique
            if(getPerso(i).getFamille().equals(f))
                lp.ajoutePerso(getPerso(i)); // Ajout du personnage à la nouvelle liste
        return lp; // Retourne la nouvelle liste contenant les personnages de la famille spécifique
    }
    
    // Méthode pour ajouter un personnage à la liste
    public void ajoutePerso(Personnage p) {
        if(p != null)
            this.persos.add(p); // Ajoute le personnage à la liste
        else
            System.out.println("Format de personnage incorrect"); // Affiche un message d'erreur si le personnage est null
    }
    
    // Méthode pour ajouter tous les personnages d'une autre liste à la liste actuelle
    public void ajoutePersos(LesPersonnages lp) {
        if(lp != null) {
            // Parcours de tous les personnages dans l'autre liste
            for(int i = 0; i < lp.getTaille(); i++) {
                this.ajoutePerso(lp.getPerso(i)); // Ajoute chaque personnage à la liste actuelle
            }
        } else {
            System.out.println("Format de paquet incorrect"); // Affiche un message d'erreur si la liste passée en paramètre est null
        }
    }
    
    // Méthode pour retirer un personnage spécifique de la liste
    public void retirePerso(Personnage p) { 
        int i = 0; 
        boolean trouve = false;
        // Parcours de tous les personnages dans la liste
        while(i < getTaille() && !trouve) {
            // Vérification si le personnage est celui à retirer
            if (getPerso(i).getNom().equals(p.getNom())) {
                this.persos.remove(i); // Retire le personnage de la liste
                trouve = true; // Indique que le personnage a été trouvé et retiré
            } else 
                i++;
        }      
    }
    
    // Méthode pour retirer un personnage à un certain indice de la liste
    public void retirePerso(int index) {
        // Vérification si l'index est valide
        if (index >= 0 && index < this.persos.size()) {
        this.persos.remove(index); // Retire le personnage à l'indice spécifié de la liste
        } else {
         System.out.println("Index invalide : " + index); // Affiche un message d'erreur si l'index est invalide
        }
    }
    
    // Méthode pour retirer un certain nombre de personnages de la liste et les renvoyer dans une nouvelle liste
    public LesPersonnages retirePersos(int n) {
        LesPersonnages lp = new LesPersonnages(); // Création d'une nouvelle liste pour stocker les personnages retirés
        // Boucle pour retirer n personnages de la liste actuelle
        for (int i = 0; i < n; i++) {
            // Ajoute le premier personnage à la liste des personnages retirés et le retire de la liste actuelle
            lp.ajoutePerso(getPerso(0));
            this.persos.remove(0);  
        }
        return lp; // Retourne la liste des personnages retirés
    } 
    
    // Méthode pour retirer tous les personnages d'une famille spécifique de la liste et les renvoyer dans une nouvelle liste
    public LesPersonnages retirePersosFamille(String f) { 
        LesPersonnages lcr = new LesPersonnages(); // Création d'une nouvelle liste pour stocker les personnages retirés
        int i = 0;
        // Parcours de tous les personnages dans la liste actuelle
        while(i < getTaille()) {
            // Vérification si le personnage appartient à la famille spécifique
            if (getPerso(i).getFamille().equals(f)) {
                lcr.ajoutePerso(getPerso(i)); // Ajoute le personnage à la liste des personnages retirés
                this.persos.remove(i); // Retire le personnage de la liste actuelle
            } else 
                i++;
        }
        return lcr; // Retourne la liste des personnages retirés
    }
    
    // Méthode pour obtenir les noms de toutes les familles présentes dans la liste
    public ArrayList<String> getStringToutesLesFamilles() {
        ArrayList<String> toReturn = new ArrayList<>(); // Création d'une liste pour stocker les noms des familles
        
        // Parcours de tous les personnages dans la liste
        for (int i = 0; i < getTaille(); i++) {
            boolean DejaAjoute = false; // Variable pour indiquer si la famille a déjà été ajoutée à la liste
            String toParse = getPerso(i).getF().getNom(); // Récupération du nom de la famille du personnage actuel
            int cmpt = 0; // Compteur pour parcourir la liste des familles déjà ajoutées
            
            // Vérification si la liste de familles à retourner n'est pas vide
            if (toReturn.size() > 0) {
                // Parcours de la liste des familles déjà ajoutées
                do {
                    // Vérification si le nom de la famille actuelle est déjà dans la liste
                    if (toParse.equals(toReturn.get(cmpt))) {
                        // La famille est déjà présente dans la liste, on indique que c'est déjà ajouté
                        DejaAjoute = true;
                    }
                    cmpt++;
                } while (!DejaAjoute && cmpt < toReturn.size()); // On continue tant qu'on n'a pas trouvé la famille ou atteint la fin de la liste
            }
            
            // Si la famille n'a pas déjà été ajoutée à la liste, on l'ajoute
            if (!DejaAjoute) {
                toReturn.add(toParse);
            }
        }
        return toReturn; // Retour de la liste contenant les noms de toutes les familles
    }
    
    // Méthode pour retirer tous les personnages de la liste
    public void retireCartes() { 
        persos.clear(); // Vide la liste des personnages
    }
    
    // Constructeur avec paramètre pour initialiser la liste avec un certain nombre de personnages
    public LesPersonnages(int nc) {
        // Initialisation de la liste des personnages
        this.persos = new ArrayList<Personnage>();
        // Ajout des personnages en fonction du nombre spécifié
        if (nc >= 4) { // 2 familles
            ajoutePerso(new Personnage("communs", "assault-trooper", 10,"/img/assault-trooper.jpg"));
            ajoutePerso(new Personnage("communs", "commando", 20,"/img/commando.jpg"));
            ajoutePerso(new Personnage("rares", "absolute-zero", 10,"/img/absolute-zero.jpg"));
            ajoutePerso(new Personnage("rares", "arctice-assassin", 20,"/img/arctice-assassin.jpg"));
        }
        if (nc >= 10) { // 4 familles
            ajoutePerso(new Personnage("communs", "devestrator", 30,"/img/devestrator.jpg"));
            ajoutePerso(new Personnage("rares", "brawler", 30,"/img/brawler.jpg"));
            ajoutePerso(new Personnage("alpins-femmes", "mogul-master", 10,"/img/mogul-master.jpg"));
            ajoutePerso(new Personnage("alpins-femmes", "mogul-master-can", 20,"/img/mogul-master-can.jpg"));
            ajoutePerso(new Personnage("as-des-pistes", "alpine-ace", 10,"/img/alpine-ace.jpg"));
            ajoutePerso(new Personnage("as-des-pistes", "alpine-ace-can", 20,"/img/alpine-ace-can.jpg"));
        }
        if (nc >= 18) { // 6 familles
            ajoutePerso(new Personnage("alpins-femmes", "mogul-master-chn", 30,"/img/mogul-master-chn.jpg"));
            ajoutePerso(new Personnage("as-des-pistes", "alpine-ace-chn", 30,"/img/alpine-ace-chn.jpg"));
            ajoutePerso(new Personnage("legendaires", "power-chord", 10,"/img/power-chord.jpg"));
            ajoutePerso(new Personnage("legendaires", "raptor", 20,"/img/raptor.jpg"));
            ajoutePerso(new Personnage("legendaires", "raven", 30,"/img/raven.jpg"));
            ajoutePerso(new Personnage("epiques", "burnout", 10,"/img/burnout.jpg"));
            ajoutePerso(new Personnage("epiques", "funk-ops", 20,"/img/funk-ops.jpg"));
            ajoutePerso(new Personnage("epiques", "rex", 30,"/img/rex.jpg"));
        }
        if (nc == 32) { // 6 familles
            ajoutePerso(new Personnage("communs", "dominator", 40,"/img/dominator.jpg"));
            ajoutePerso(new Personnage("communs", "highrise-assault-trooper", 50,"/img/highrise-assault-trooper.jpg"));
            ajoutePerso(new Personnage("communs", "jungle-scout", 60,"/img/jungle-scout.jpg"));
            ajoutePerso(new Personnage("communs", "pathfinder", 70,"/img/pathfinder.jpg"));
            ajoutePerso(new Personnage("rares", "brilliant-striker", 40,"/img/brilliant-striker.jpg"));
            ajoutePerso(new Personnage("rares", "brite-bomber", 50,"/img/brite-bomber.jpg"));
            ajoutePerso(new Personnage("rares", "circuit-breaker", 60,"/img/circuit-breaker.jpg"));
            ajoutePerso(new Personnage("rares", "dazzle", 70,"/img/dazzle.jpg"));
            ajoutePerso(new Personnage("alpins-femmes", "mogul-master-fra", 40,"/img/mogul-master-fra.jpg"));
            ajoutePerso(new Personnage("alpins-femmes", "mogul-master-gbr", 50,"/img/mogul-master-gbr.jpg"));
            ajoutePerso(new Personnage("as-des-pistes", "alpine-ace-fra", 40,"/img/alpine-ace-fra.jpg"));
            ajoutePerso(new Personnage("as-des-pistes", "alpine-ace-gbr", 50,"/img/alpine-ace-gbr.jpg"));
            ajoutePerso(new Personnage("legendaires", "red-knight", 40,"/img/red-knight.jpg"));
            ajoutePerso(new Personnage("epiques", "shadow-ops", 40,"/img/shadow-ops.jpg"));
        }
    }
    
    // Méthode toString pour afficher la liste des personnages
    @Override
    public String toString() {
        String s = "";
        // Parcours de tous les personnages dans la liste
        for(int i = 0; i < getTaille(); i++)
            s += i + "- " + getPerso(i).toString() + "\n"; // Ajoute les informations du personnage à la chaîne de caractères
    return s; // Retourne la chaîne contenant la liste des personnages
    }
}