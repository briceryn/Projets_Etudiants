/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package JeuMemory;

/**
 *
 * @author Brice
 */
public class Jeu {
    
    private LesPersonnages lstPerso;// collection des personnages utilisés pour le jeu
    private PlateauJeu plateau;// plateau du jeu
    private LesJoueurs lstPlayers;// joueurs qui participent au jeu
    private Action act;// action accomplie par le joueur courant le cas échéant
    private int indC; // indice du joueur courant
    private int nbc;
    
    
    public Jeu(LesPersonnages lp, LesJoueurs lj,int nbc){ // nbc  nombre case
        this.lstPerso=lp;
        this.plateau=new PlateauJeu(nbc);
        this.lstPlayers=lj;
        this.act=null;// Initialisation à null
        this.indC=0;// Initialisation à 0
        this.nbc = nbc;
    }
    
    // Getter et Setter pour le plateau de jeu
    public LesPersonnages getLstPerso() {
        return lstPerso;
    }

    public void setLstPerso(LesPersonnages lstPerso) {
        this.lstPerso = lstPerso;
    }

    // Getter et Setter pour le plateau de jeu
    public PlateauJeu getPlateau() {
        return plateau;
    }

    public void setPlateau(PlateauJeu plateau) {
        this.plateau = plateau;
    }

    // Getter et Setter pour la liste des joueurs
    public LesJoueurs getLstPlayers() {
        return lstPlayers;
    }

    public void setLstPlayers(LesJoueurs lstPlayers) {
        this.lstPlayers = lstPlayers;
    }
    
    // Getter et Setter pour l'indice du joueur courant
    public int getIndiceJoueurCourant() {
        return indC;
    }

    public void setIndiceJoueurCourant(int indC) {
        this.indC = indC;
    }
    
    // Méthode pour obtenir le joueur courant
    public Joueur getJoueurCourant(){
        return lstPlayers.getJoueur(indC);
    } 

     // Getter et Setter pour l'action en cours
    public Action getAct() {
        return act;
    }

    public void setAct(Action act) {
        this.act = act;
    }
    
   // Pour obtenir l'indice du joueur suivant
    public int getIndiceJoueurSuivant(int j) {
        return (j +1) % lstPlayers.getNbJoueurs();
    }
    
    // Pour obtenir le joueur suivant à partir de l'indice du joueur actuel
    public Joueur getJoueurSuivant(int j) {
        int indiceJoueurSuivant = getIndiceJoueurSuivant(j);
        return lstPlayers.getJoueur(indiceJoueurSuivant);
    }

    // Pour obtenir le joueur suivant à partir du joueur actuel
    public Joueur getJoueurSuivant(Joueur joueurCourant) {
        int indiceJoueurCourant = lstPlayers.getIndiceJoueur(joueurCourant);
        int indiceJoueurSuivant = getIndiceJoueurSuivant(indiceJoueurCourant);
        return lstPlayers.getJoueur(indiceJoueurSuivant);
    }
    
    // Méthode pour vérifier si le jeu est terminé
    public boolean finJeu()  {
        return plateau.jeuVide();
    }
    
    // retourne le nb total de personnages des autres joueurs
    public int nbPers(){
        int n = 0;
        for(int i = 0; i < lstPlayers.getNbJoueurs(); i++){
            if (i !=this.indC){
                n+=lstPlayers.getJoueur(i).getPaquet().getTaille();
            }
        }return n; 
    }
    
    public int traiterTour(Joueur joueurCourant, int indicePersonnageGagnant) {
    int bonus = -1; // Initialisation du bonus à -1
    
    // Récupération du personnage gagné à partir de son indice
    Personnage personnageGagnant = lstPerso.getPerso(indicePersonnageGagnant);
    
    // Ajout du personnage gagnant au paquet du joueur courant
    joueurCourant.ajoutePersoPaquet(personnageGagnant);
    
    // Récupération du nom de la famille du personnage gagnant
    String nomFamillePersonnageGagnant = personnageGagnant.getFamille();
    
    // Récupération du nombre total de personnages de cette famille dans le jeu
    int nbTotalPersonnagesFamille = lstPerso.getPersosFamille(nomFamillePersonnageGagnant).getTaille();
    
    // Récupération du nombre de personnages de cette famille dans le paquet du joueur courant
    int nbPersonnagesFamilleJoueur = joueurCourant.getPaquet().getPersosFamille(nomFamillePersonnageGagnant).getTaille();
    
    if (nbTotalPersonnagesFamille == nbPersonnagesFamilleJoueur) {
        // Si le joueur a toutes les cartes de sa famille préférée
        if (nomFamillePersonnageGagnant.equals(joueurCourant.getFp())) {
            bonus = 0; // Fixer le bonus à 0
            plateau.termineJeu(); // Indiquer la fin du jeu
        }
        else {

            // Si la famille du personnage gagnant est "rares" ou "communs"
            if (nomFamillePersonnageGagnant.equals("rares") || nomFamillePersonnageGagnant.equals("communs")) {
                bonus = 1; // Fixer le bonus à 1 (transfert de cartes)
            } else {
                // Si la famille du personnage gagnant est "alpins-femmes" ou "as-des-pistes"
                if (nomFamillePersonnageGagnant.equals("alpins-femmes") || nomFamillePersonnageGagnant.equals("as-des-pistes")) {
                    bonus = 3; // Fixer le bonus à 3 (combat)
                } else {
                    bonus = 2; // Fixer le bonus à 2 (bataille)
                }
            }
        }
    }
    
    // Retourner la valeur du bonus
    return bonus;
}

    public int[] getJoNbCartesParFamille(Joueur jo) {
    LesPersonnages enPossession = jo.getPaquet();
    int communs = 0;
    int rares = 0;
    int legendaires = 0;
    int epiques = 0;
    
    // Parcourir le paquet de personnages du joueur
    for (Personnage perso : enPossession.getPersos()) {
        String famille = perso.getFamille(); // Récupérer la famille du personnage
        
        // Incrémenter le compteur correspondant en fonction de la famille du personnage
        switch (famille) {
            case "communs":
                communs++;
                break;
            case "rares":
                rares++;
                break;
            case "legendaires":
                legendaires++;
                break;
            case "epiques":
                epiques++;
                break;
            default:
                // Do nothing
                break;
        }
    }
    
    // Retourner le nombre de cartes pour chaque famille
    return new int[]{communs, rares, legendaires, epiques};
}    
}
