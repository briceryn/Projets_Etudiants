/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package JeuMemory;

/**
 *
 * @author Brice
 */
public abstract class Action {
    /* Action est une classe abstraite qui a deux classes filles :
     * - Transfert
     * - Bataille
     * Cette classe représente une action effectuée par un joueur dans le jeu.
     */

    // Déclaration des attributs de la classe Action
    private Joueur j; // Joueur à l'origine de l'action
    private String descriptif; // Nature de l'action
    private String deroulement; // Description de l'action

    // Méthode abstraite pour exécuter l'action
    public abstract int execute();

    // Constructeur avec paramètres pour initialiser le joueur et le descriptif de l'action
    public Action(Joueur sc, String s) {
        this.setJoueur(sc);
        this.setDescriptif(s);
        this.setDeroulement("");
    }

    // Accesseurs pour les attributs de la classe Action

    /**
     * Renvoie le joueur à l'origine de l'action.
     * 
     * @return Le joueur à l'origine de l'action
     */
    public Joueur getJoueurCourant() {
        return j;
    }

    /**
     * Modifie le joueur à l'origine de l'action.
     * 
     * @param j Le joueur à définir comme l'origine de l'action
     */
    public void setJoueur(Joueur j) {
        this.j = j;
    }

    /**
     * Renvoie la nature de l'action.
     * 
     * @return La nature de l'action
     */
    public String getDescriptif() {
        return descriptif;
    }

    /**
     * Modifie la nature de l'action.
     * 
     * @param descriptif La nature de l'action à définir
     */
    public void setDescriptif(String descriptif) {
        this.descriptif = descriptif;
    }

    /**
     * Renvoie la description détaillée de l'action.
     * 
     * @return La description détaillée de l'action
     */
    public String getDeroulement() {
        return deroulement;
    }

    /**
     * Modifie la description détaillée de l'action.
     * 
     * @param deroulement La description détaillée de l'action à définir
     */
    public void setDeroulement(String deroulement) {
        this.deroulement = deroulement;
    }

    // Méthode toString pour obtenir une représentation textuelle de l'action
    @Override
    public String toString() {
        return "Action effectuée par " + j.getPseudo() + " : " + descriptif + "\n" + this.deroulement + "\n";
    }
}
