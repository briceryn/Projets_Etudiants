/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package JeuMemory;

/**
 *
 * @author Brice
 */
public class Famille {
    // Définition des familles communes avec leurs attributs statiques
    public static Famille communs = new Famille("communs", 4);
    public static Famille rares = new Famille("rares", 4);
    public static Famille alpinsFemmes = new Famille("alpins-femmes", 10);
    public static Famille asDesPistes = new Famille("as-des-pistes", 10);
    public static Famille epiques = new Famille("epiques", 18);
    public static Famille legendaires = new Famille("legendaires", 18);
    
    // Attributs de la famille
    private String nom; // Nom de la famille
    private int difficulte; // Niveau de difficulté de la famille
    private int nbMaxPerso; // Nombre maximal de personnages dans la famille
    
    // Constructeur avec paramètres pour initialiser une famille
    public Famille(String nom, int difficulty) {
        this.nom = nom;
        this.difficulte = difficulty;
    }
    
    // Méthode pour obtenir le nom de la famille
    public String getNom() {
        return nom;
    }

    // Méthode pour définir le nom de la famille
    public void setNom(String nom) {
        this.nom = nom;
    }

    // Méthode pour obtenir le niveau de difficulté de la famille
    public int getDifficulty() {
        return difficulte;
    }

    // Méthode pour définir le niveau de difficulté de la famille
    public void setDifficulty(int difficulty) {
        this.difficulte = difficulty;
    }

    // Méthode pour obtenir le nombre maximal de personnages dans la famille
    public int getNbMaxPerso() {
        return nbMaxPerso;
    }

    // Méthode pour définir le nombre maximal de personnages dans la famille
    public void setNbMaxPerso(int nbMaxPerso) {
        this.nbMaxPerso = nbMaxPerso;
    }
    
    // Méthode pour vérifier l'égalité entre deux familles
    public boolean equals(Famille f) {
        if(f != null) {
            return f.getNom().equals(nom) && f.getDifficulty() == difficulte;
        } else {
            return false;
        }
    }
    
    // Méthode toString pour obtenir une représentation textuelle de la famille
    @Override
    public String toString() {
        return nom;
    }
}
