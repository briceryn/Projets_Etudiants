/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package JeuMemory;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.Timer;

/**
 *
 * @author Brice
 */

public class JeuMemory extends javax.swing.JFrame {
    /**
     * Creates new form JeuMemory
     */
    private LesPersonnages LesPers ;// collection des personnages utilisés pour le jeu
    private LesJoueurs joueurs ;// joueurs qui participent au jeu
    private Jeu Monjeu;// pour la gestion d’un tour de jeu
    private int l1 ; // Coordonnée de ligne de la première carte
    private int c1 ; // Coordonnée de colonne de la première carte
    private int l2 ;// Coordonnée de ligne de la deuxieme carte
    private int c2 ;// Coordonnée de colonne de la deuxieme carte
    private PlateauJeu plateau; // plateau qui sera récupéré à partir du jeu lors de son initialisation
    private int nbc;//Nombre de personnages qui diminue au cours du jeu
    private int nbcInit; //la valeur initiale de nbc
    
    
    


    
/**
 * Constructeur de la classe JeuMemory.
 * Initialise l'interface utilisateur et les données de jeu.
 */
public JeuMemory() {
    // Initialisation des composants de l'interface utilisateur
    initComponents();
    
    // Création d'une nouvelle collection de personnages par défaut de niveau débutant
    this.LesPers = new LesPersonnages();
    
    // Initialisation de la collection des joueurs
    this.joueurs = new LesJoueurs();
    
    // Initialisation des coordonnées des cartes à -1, indiquant qu'aucune carte n'a été sélectionnée
    this.l1 = -1;
    this.c1 = -1;
    this.l2 = -1;
    this.c2 = -1;
    
    // Création d'une nouvelle instance de jeu avec les personnages et les joueurs initialisés
    this.Monjeu = new Jeu(this.LesPers, this.joueurs, 4);
    
    // Récupération du plateau de jeu à partir de l'instance de jeu
    this.plateau = this.Monjeu.getPlateau();
    
    // Initialisation du nombre de personnages restants sur le plateau de jeu
    this.nbc = plateau.getNbp();
    
    // Stockage de la valeur initiale du nombre de personnages restants
    this.nbcInit = this.nbc;
    
    // Désactivation du bouton "Recommencer" au démarrage du jeu
    recommencer.setEnabled(false);
    
    // Désactivation du bouton "Joueur" au démarrage du jeu
    joueur.setEnabled(false);
    
    // Désactivation du bouton "Carte" au démarrage du jeu
    Carte.setEnabled(false);
}
    

    public void startTimer() {
    // Définit un timer qui lance la vérification des deux personnages au bout d'une demi-seconde
    Timer timer = new Timer(300, new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent ae) {
            verifPersos();
        }
    });
    
    // Indique que le timer ne doit pas se répéter après avoir effectué une action
    timer.setRepeats(false);
    
    // Démarre le timer
    timer.start();
    }
    

  /**
 * Méthode pour vérifier si les personnages des deux cartes retournées sont identiques.
 * Elle gère également les actions à effectuer en fonction du résultat de la vérification.
 */
public void verifPersos() {
    // Variable pour indiquer si un joueur a gagné
    boolean gagnant = false;
    
    // Récupération des personnages des deux cartes
    int perso1 = plateau.getCase(l1, c1);
    int perso2 = plateau.getCase(l2, c2);
   
    // Vérification si les personnages des deux cartes sont identiques et ne sont pas de la même famille
    if (perso1 == perso2 && (plateau.getCaseCode(l1, c1) != plateau.getCaseCode(l2, c2))) {
        nbc = Monjeu.getPlateau().getNbp();
        // Si les personnages des deux cartes sont identiques
        
        // Retournement des cartes
        CartesRetourne();
        
        // Récupération du personnage gagné par le joueur
        Personnage perso = LesPers.getPerso(Monjeu.getPlateau().getCase(l2, c2));
        
        // Traitement du tour de jeu et obtention du bonus
        int bonus = Monjeu.traiterTour(Monjeu.getJoueurCourant(), perso1);
        
        if (bonus >= 0) {
            switch (bonus) {
                case 0:
                    // Affichage du message de victoire
                    Edition.append(Monjeu.getJoueurCourant().getPseudo() + " a obtenu tous les personnages de sa famille préférée\n\n");
                    gagnant = true;
                    // Fin du jeu, blocage des boutons, etc.
                    plateau.termineJeu();
                    AfficherGagnant();
                    break;
                case 1:
                    // Affichage du message de bonus pour avoir obtenu tous les personnages d'une famille
                    Edition.append(Monjeu.getJoueurCourant().getPseudo() + " a obtenu tous les personnages de la famille rares/communs!\n\n");
                    // Ouverture de la boîte de dialogue de transfert
                    TransfertDlg diag = new TransfertDlg(this, true, joueurs, Monjeu.getIndiceJoueurCourant());
                    diag.setSize(600, 600);
                    diag.setVisible(true);
                    // Affichage du résultat du transfert
                    break;
                case 2:
                    // Affichage du message de bonus pour avoir obtenu tous les personnages de la famille legendaires
                    Edition.append(Monjeu.getJoueurCourant().getPseudo() + " a obtenu tous les personnages de la famille legendaires!\nBataille en cours...\n\n");
                    // Ouverture de la boîte de dialogue de bataille
                    BatailleDlg Batt = new BatailleDlg(this, true, joueurs, Monjeu.getIndiceJoueurCourant());
                    Batt.setSize(1000, 600);
                    Batt.setVisible(true);
                    break;
            }
        }
        // Retrait des cartes du plateau
        Monjeu.getPlateau().invalide(l1, c1, l2, c2);

        // Vérification s'il n'y a plus de cartes à retourner
        if (!gagnant) {
            if (Monjeu.getPlateau().jeuVide()) {
                // Affichage des gagnants
                AfficherGagnant();
                finJeuBoutons();
            } else {
                // Changement du joueur courant et mise à jour de l'affichage
                changeJoueurCourant();
                updateJLabel();
            }           
        }
    } else {
        // Si les cartes sont différentes
        
        // Changement du joueur courant au joueur suivant
        // Réinitialisation des positions des cartes retournées
        changeJoueurCourant();
        cleanReturnedCards(); 
        updateJLabel();
    }

    // Réinitialisation des valeurs des positions des cartes
    l1 = c1 = l2 = c2 = -1;
    
    // Mise à jour du nombre de personnages restants
    nbc = Monjeu.getPlateau().getNbp();
    updateJLabel(); 
}
    
/**
 * Méthode pour réactiver les écouteurs des boutons dans le panneau de jeu.
 */
private void reactiverEcouteurs() {
    // Récupération de tous les composants dans le panneau de jeu
    Component[] composants = Panneau.getComponents();
    
    // Parcours de tous les composants
    for (Component comp : composants) {
        // Vérification si le composant est un bouton
        if (comp instanceof JButton) {
            // Conversion du composant en bouton
            JButton bouton = (JButton) comp;
            
            // Activation du bouton
            bouton.setEnabled(true);
        }
    }
}
    
/**
 * Méthode pour désactiver tous les boutons dans le panneau de jeu.
 */
private void desactiverBoutons() {
    // Récupération de tous les composants dans le panneau de jeu
    Component[] composants = Panneau.getComponents();
    
    // Parcours de tous les composants
    for (Component comp : composants) {
        // Vérification si le composant est un bouton
        if (comp instanceof JButton) {
            // Conversion du composant en bouton
            JButton bouton = (JButton) comp;
            
            // Désactivation du bouton
            bouton.setEnabled(false);
        }
    }
}


/**
 * Méthode pour initialiser le jeu Memory.
 */
public void initJeumemory(){
    // Création d'une nouvelle instance de jeu avec les personnages, les joueurs et le nombre de colonnes
    Monjeu = new Jeu(LesPers,joueurs,nbc);
    
    // Suppression du JLabel "Message" de son conteneur
    Panneau.remove(Message);
    
    // Actualisation de l'interface du conteneur
    Panneau.revalidate();
    
    // Redessin du conteneur pour refléter les modifications
    Panneau.repaint();
    
    // Configuration de la disposition du panneau de jeu en GridLayout avec le nombre de lignes et de colonnes du plateau de jeu
    Panneau.setLayout(new GridLayout(Monjeu.getPlateau().getNbLig(),Monjeu.getPlateau().getNbCol()));
    
    // Création des boutons de cartes pour chaque case du plateau de jeu
    for(int i = 0; i < nbc*2; i++){
        JButton  Btcarte = new JButton();
        Btcarte.setPreferredSize(new Dimension(150,150));
        Btcarte.setName(String.valueOf(i));
        // Ajout d'un écouteur d'action pour chaque bouton de carte
        Btcarte.addActionListener(new ActionListener(){ 
            @Override
            public void actionPerformed(ActionEvent evt){
                boutonActionPerformed(evt);
            }
        });
        Panneau.add(Btcarte);
    }
    
    // Mise à jour de l'affichage des informations
    updateJLabel();
    
    // Affichage du nombre de personnages restants
    NbPersoRestant(nbc);
    
    // Affichage du nombre de personnages trouvés
    NbPersoTrouve(0);
    
    // Redimensionnement de la fenêtre pour s'adapter au contenu
    this.pack();
    
    // Affichage du joueur courant dans la zone d'édition
    Edition.append(Monjeu.getJoueurCourant().toString()+"\n\n");
}
        
/**
 * Désactive tous les boutons du plateau de jeu à la fin du jeu.
 */
public void finJeuBoutons() {
    for (int i = 0; i < 2 * Monjeu.getPlateau().getNbc(); i++) {
        JButton button = (JButton) Panneau.getComponent(i);
        button.setEnabled(false);
    }
}

/**
 * Supprime tous les joueurs, les éléments du panneau et réinitialise la zone d'édition.
 */
private void SupprimeTout() {
    joueurs.supprimetousJoueur();
    Panneau.removeAll();
    Edition.setText("");
}

/**
 * Met à jour le nombre de personnages trouvés dans l'interface graphique.
 * @param nb Le nombre de personnages trouvés.
 */
private void NbPersoTrouve(int nb) {
    Trouve.setText("Nb de personnages trouvés : " + nb);
}

/**
 * Met à jour le nombre de personnages restants dans l'interface graphique.
 * @param nb Le nombre de personnages restants.
 */
private void NbPersoRestant(int nb) {
    Restant.setText("Nb de personnages restants : " + nb);
}

/**
 * Affiche le joueur courant dans la zone d'édition.
 * @param name Le nom du joueur courant.
 */
private void TourJcourant(String name) {
    Tourjoueur.setText("C'est à " + name + " de jouer !");
}

/**
 * Met à jour les informations affichées dans l'interface graphique.
 */
private void updateJLabel() {
    TourJcourant(Monjeu.getJoueurCourant().getPseudo());
    NbPersoRestant(nbc);
    NbPersoTrouve(nbcInit - nbc);
}

/**
 * Affiche le gagnant ou les gagnants dans la zone d'édition.
 */
private void AfficherGagnant() {
    LesJoueurs gagnant = joueurs.getGagnant();
    if (gagnant.getNbJoueurs() == 1) {
        Edition.append(gagnant.getJoueur(0).getPseudo() + " a gagné !\n\n");
    } else {
        StringBuilder toShow = new StringBuilder();
        for (int i = 0; i < gagnant.getNbJoueurs(); i++) {
            toShow.append(gagnant.getJoueur(i).getPseudo()).append(", ");
        }
        toShow.append("ont gagné !");
        Edition.append(toShow.toString() + "\n\n");
    }
}

/**
 * Change le joueur courant et met à jour les informations affichées.
 */
public void changeJoueurCourant() {
    int nbJoueur = joueurs.getNbJoueurs();
    int prochainJoueurCourant = Monjeu.getIndiceJoueurCourant() + 1;
    if (prochainJoueurCourant == nbJoueur) {
        prochainJoueurCourant = 0;
    }
    Monjeu.setIndiceJoueurCourant(prochainJoueurCourant);
    updateJLabel();
    Edition.append(Monjeu.getJoueurCourant().toString() + "\n\n");
}

/**
 * Efface les cartes retournées en remettant leur icône à null.
 */
public void cleanReturnedCards() {
    int positionButton1 = l1 * Monjeu.getPlateau().getNbCol() + c1;
    int positionButton2 = l2 * Monjeu.getPlateau().getNbCol() + c2;
    JButton button1 = (JButton) Panneau.getComponent(positionButton1);
    JButton button2 = (JButton) Panneau.getComponent(positionButton2);
    button1.setIcon(null);
    button2.setIcon(null);
}

/**
 * Désactive les boutons des cartes retournées pour les empêcher d'être cliqués à nouveau.
 */
public void CartesRetourne() {
    int positionButton1 = l1 * Monjeu.getPlateau().getNbCol() + c1;
    int positionButton2 = l2 * Monjeu.getPlateau().getNbCol() + c2;
    JButton button1 = (JButton) Panneau.getComponent(positionButton1);
    JButton button2 = (JButton) Panneau.getComponent(positionButton2);
    button1.setEnabled(false);
    button2.setEnabled(false);
}

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Panneau = new javax.swing.JPanel();
        Message = new javax.swing.JLabel();
        jPanel2 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        demarrer = new javax.swing.JButton();
        recommencer = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        Edition = new javax.swing.JTextArea();
        jPanel4 = new javax.swing.JPanel();
        Trouve = new javax.swing.JLabel();
        Restant = new javax.swing.JLabel();
        Tourjoueur = new javax.swing.JLabel();
        jMenuBar1 = new javax.swing.JMenuBar();
        parametres = new javax.swing.JMenu();
        option = new javax.swing.JMenuItem();
        AjoutJoueur = new javax.swing.JMenuItem();
        visualiser = new javax.swing.JMenu();
        joueur = new javax.swing.JMenuItem();
        Carte = new javax.swing.JMenuItem();
        Test = new javax.swing.JMenu();
        Transfert = new javax.swing.JMenuItem();
        Bataille = new javax.swing.JMenuItem();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        Panneau.setLayout(new java.awt.GridLayout(4, 5));

        Message.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Message.setText("\"Veuillez paramétrer le jeu avant de commencer.\"");
        Panneau.add(Message);

        getContentPane().add(Panneau, java.awt.BorderLayout.CENTER);

        jPanel2.setLayout(new java.awt.BorderLayout());

        jPanel3.setLayout(new java.awt.GridLayout(1, 2));

        demarrer.setText("Demarrer");
        demarrer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                demarrerActionPerformed(evt);
            }
        });
        jPanel3.add(demarrer);

        recommencer.setText("Recommencer");
        recommencer.setToolTipText("");
        recommencer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                recommencerActionPerformed(evt);
            }
        });
        jPanel3.add(recommencer);

        jPanel2.add(jPanel3, java.awt.BorderLayout.SOUTH);

        Edition.setColumns(20);
        Edition.setRows(5);
        jScrollPane1.setViewportView(Edition);

        jPanel2.add(jScrollPane1, java.awt.BorderLayout.CENTER);

        jPanel4.setLayout(new java.awt.GridLayout(3, 1));
        jPanel4.add(Trouve);
        jPanel4.add(Restant);
        jPanel4.add(Tourjoueur);

        jPanel2.add(jPanel4, java.awt.BorderLayout.PAGE_START);

        getContentPane().add(jPanel2, java.awt.BorderLayout.WEST);

        parametres.setText("Paramètres");

        option.setText("Options");
        option.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optionActionPerformed(evt);
            }
        });
        parametres.add(option);

        AjoutJoueur.setText("Ajout joueur");
        AjoutJoueur.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                AjoutJoueurActionPerformed(evt);
            }
        });
        parametres.add(AjoutJoueur);

        jMenuBar1.add(parametres);

        visualiser.setText("Visualiser");

        joueur.setText("Joueur");
        joueur.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                joueurActionPerformed(evt);
            }
        });
        visualiser.add(joueur);

        Carte.setText("Carte");
        Carte.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CarteActionPerformed(evt);
            }
        });
        visualiser.add(Carte);

        jMenuBar1.add(visualiser);

        Test.setText("MenuTest");

        Transfert.setText("Transfert");
        Transfert.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                TransfertActionPerformed(evt);
            }
        });
        Test.add(Transfert);

        Bataille.setText("Bataille");
        Bataille.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BatailleActionPerformed(evt);
            }
        });
        Test.add(Bataille);

        jMenuBar1.add(Test);

        setJMenuBar(jMenuBar1);

        pack();
    }// </editor-fold>//GEN-END:initComponents
   private void boutonActionPerformed(ActionEvent evt) {
        // Récupération du bouton qui a été cliqué
        JButton boutonClique = (JButton) evt.getSource();
        
        // Récupération du nom du bouton qui est son numéro
        int numeroCarte = Integer.parseInt(boutonClique.getName());
    
        // Calcul du numéro de ligne et de colonne correspondant à ce numéro
        int ligne = numeroCarte / plateau.getNbCol();
        int colonne = numeroCarte % plateau.getNbCol();
    
        // Vérifier si la carte a déjà été retournée
    
        // Récupération du numéro du personnage associé à cette carte dans le plateau
        int numeroPersonnage = plateau.getCase(ligne, colonne);
    
        // Récupération du personnage de cette carte à partir de son numéro
        Personnage personnage = LesPers.getPerso(numeroPersonnage);

        // Obtenir la photo du personnage
        ImageIcon photo = new ImageIcon(personnage.getPhoto());

        // Redimensionner l'image pour qu'elle occupe toute la dimension du bouton
        Image img = photo.getImage();
        Image imgScaled = img.getScaledInstance(boutonClique.getWidth(), boutonClique.getHeight(), Image.SCALE_SMOOTH);
        ImageIcon photoScaled = new ImageIcon(imgScaled);

        // Affichage de la photo redimensionnée du personnage sur le bouton cliqué
        boutonClique.setIcon(photoScaled);
        

    
        // Vérifier si c'est la première case cliquée
        if (l1 == -1 && c1 == -1) {
            // Affecter ligne et colonne calculées à l1 et c1
            l1 = ligne;
            c1 = colonne;
        } 
        // Sinon, s'il s'agit de la deuxième case
        else if (l2 == -1 && c2 == -1) {
            // Affecter les lignes et colonnes calculées à l2 et c2
            l2 = ligne;
            c2 = colonne;
        
        // Appeler la méthode startTimer
        startTimer();
    }
}


    private void demarrerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_demarrerActionPerformed
        // Vérifier si le nombre de joueurs est inférieur à 2
        if (joueurs.getNbJoueurs() < 2) {
            // Afficher un message d'erreur dans la zone d'édition
            Edition.setText("Il doit y avoir au moins 2 joueurs pour démarrer la partie.");
        } else {
            // Désactiver le bouton "Démarrer" et activer le bouton "Recommencer"
        demarrer.setEnabled(false);
        recommencer.setEnabled(true);

       // Désactiver les sous-options de menu "Options" et "Ajout Joueur"
        option.setEnabled(false);
        AjoutJoueur.setEnabled(false);

        // Activer les sous-options de menu "Joueurs" et "Cartes" de l'option "Visualisation"
        joueur.setEnabled(true);
        Carte.setEnabled(true);
        // Construire dynamiquement le panneau des cartes
        initJeumemory();
    }

    }//GEN-LAST:event_demarrerActionPerformed
/**
 * Méthode appelée lorsque le bouton "Recommencer" est cliqué.
 * Cette méthode réinitialise le jeu et prépare l'interface graphique pour une nouvelle partie.
 */
    private void recommencerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_recommencerActionPerformed
    // Supprime tous les joueurs, les éléments du panneau et réinitialise la zone d'édition
    SupprimeTout();
    // Réinitialise les personnages, les joueurs, le plateau et d'autres variables du jeu
    this.LesPers = new LesPersonnages(); // par défaut niveau débutant
    this.joueurs = new LesJoueurs();
    this.l1 = -1; this.c1 = -1; this.l2 = -1; this.c2 = -1;
    this.Monjeu = new Jeu(this.LesPers, this.joueurs, 4);
    this.plateau = this.Monjeu.getPlateau();
    this.nbc = plateau.getNbp();
    this.nbcInit = this.nbc; // Stocker la valeur initiale de nbc
    
    // Désactive les boutons qui ne sont pas nécessaires au début de la partie
    recommencer.setEnabled(false);
    joueur.setEnabled(false);
    Carte.setEnabled(false);
    
    // Active les boutons nécessaires pour démarrer une nouvelle partie
    demarrer.setEnabled(true);
    option.setEnabled(true);
    AjoutJoueur.setEnabled(true);
    
    // Redessine le panneau pour refléter les modifications
    Panneau.repaint();
    
    // Réinitialise les indicateurs du nombre de personnages trouvés et restants
    Trouve.setText("Nb de personnages trouvés : 0");
    Restant.setText("Nb de personnages restants : 0");
    
    // Affiche un message indiquant que le jeu doit être paramétré avant de commencer
    Tourjoueur.setText("Veuillez Parametrer le jeu");
    Message.setText("Veuillez paramétrer le jeu avant de commencer.");
    Panneau.add(Message); // Ajoute le message au panneau


    }//GEN-LAST:event_recommencerActionPerformed

    private void optionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_optionActionPerformed
        // Création de la boîte de dialogue d'initialisation
        InitDlg choix = new InitDlg(this,true);

        // Définition de la taille de la boîte de dialogue
        choix.setSize(900,600);

        // Rendre la boîte de dialogue visible à l'utilisateur
        choix.setVisible(true);

        // Vérifier si l'utilisateur a confirmé ses choix dans la boîte de dialogue
        if (choix.isOk()) {
        // Récupérer les joueurs sélectionnés depuis la boîte de dialogue
        LesJoueurs mesJ = choix.getLj();
    
            // Ajouter les joueurs sélectionnés aux joueurs existants
            for(int i = 0; i < mesJ.getNbJoueurs(); i++) {
                this.joueurs.ajouteJoueur(mesJ.getJoueur(i));
            }
    
            // Initialiser les personnages en fonction du nombre de cases sélectionné
            this.LesPers = new LesPersonnages(choix.getNc());
    
            // Initialiser le jeu avec les personnages et les joueurs
            this.Monjeu = new Jeu(this.LesPers, this.joueurs, choix.getNc());
    
            // Récupérer le plateau de jeu de l'instance de jeu créée
             this.plateau = new PlateauJeu(choix.getNc());
             this.nbc = choix.getNc();
             
        }
    }//GEN-LAST:event_optionActionPerformed

    private void AjoutJoueurActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_AjoutJoueurActionPerformed
        // Création de la boîte de dialogue de saisie des joueurs
        SaisieJoueurDlg choix = new SaisieJoueurDlg(this, true, this.LesPers);

        // Définition de la taille de la boîte de dialogue
        choix.setSize(600, 400);

        // Rendre la boîte de dialogue visible à l'utilisateur
        choix.setVisible(true);

        // Vérifier si l'utilisateur a confirmé la saisie du joueur dans la boîte de dialogue
        if (choix.isOk()) {
            // Récupérer le joueur saisi depuis la boîte de dialogue
            Joueur joueurSaisi = choix.getJ();

            // Ajouter le joueur saisi aux joueurs existants
            joueurs.ajouteJoueur(joueurSaisi);
        }
    }//GEN-LAST:event_AjoutJoueurActionPerformed

    private void joueurActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_joueurActionPerformed
        // Création de la boîte de dialogue pour visualiser les joueurs
        VisuJoueursDlg choix = new VisuJoueursDlg(this, true, this.joueurs);

        // Définition de la taille de la boîte de dialogue
        choix.setSize(1000, 400);

        // Rendre la boîte de dialogue visible à l'utilisateur
        choix.setVisible(true);
    }//GEN-LAST:event_joueurActionPerformed

    private void CarteActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CarteActionPerformed
        // TODO add your handling code here:
        VisuPersonnagesDlg Visupersos = new VisuPersonnagesDlg(this, true,this.Monjeu.getJoueurCourant());
        Visupersos.setSize(600,400);
        Visupersos.setVisible(true);
        
    }//GEN-LAST:event_CarteActionPerformed

    private void TransfertActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_TransfertActionPerformed
        Joueur j1=new Joueur("FanMemory1", "commun");
        j1.getPaquet().ajoutePerso(new Personnage("communs", "assault-trooper", 10,"/img/assault-trooper.jpg"));
        j1.getPaquet().ajoutePerso(new Personnage("communs", "commando", 20,"/img/commando.jpg"));
        j1.getPaquet().ajoutePerso(new Personnage("rares", "absolute-zero", 10,"/img/absolute-zero.jpg"));
        Joueur j2=new Joueur("FanMemory2", "commun");
        j2.getPaquet().ajoutePerso(new Personnage("epiques", "burnout", 20,"/img/burnout.jpg"));
        j2.getPaquet().ajoutePerso(new Personnage("epiques", "funk-ops", 30,"/img/funk-ops.jpg"));
        j2.getPaquet().ajoutePerso(new Personnage("alpins-femmes", "mogul-master", 10,"/img/mogul-master.jpg"));
        LesJoueurs lj= new LesJoueurs();
        lj.ajouteJoueur(j1);
        lj.ajouteJoueur(j2);
        TransfertDlg diag = new TransfertDlg(this,true,lj,0 );
        diag.setVisible(true);
    }//GEN-LAST:event_TransfertActionPerformed

    private void BatailleActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BatailleActionPerformed
        Joueur j1=new Joueur("FanMemory1", "commun");
        j1.getPaquet().ajoutePerso(new Personnage("communs", "assault-trooper", 10,"/img/assault-trooper.jpg"));
        j1.getPaquet().ajoutePerso(new Personnage("communs", "commando", 20,"/img/commando.jpg"));
        j1.getPaquet().ajoutePerso(new Personnage("rares", "absolute-zero", 10,"/img/absolute-zero.jpg"));
        Joueur j2=new Joueur("FanMemory2", "commun");
        j2.getPaquet().ajoutePerso(new Personnage("epiques", "burnout", 20,"/img/burnout.jpg"));
        j2.getPaquet().ajoutePerso(new Personnage("epiques", "funk-ops", 30,"/img/funk-ops.jpg"));
        j2.getPaquet().ajoutePerso(new Personnage("alpins-femmes", "mogul-master", 10,"/img/mogul-master.jpg"));
        LesJoueurs lj= new LesJoueurs();
        lj.ajouteJoueur(j1);
        lj.ajouteJoueur(j2);
        BatailleDlg diag = new BatailleDlg(this, true, lj,0);
        diag.setSize(1000,600);
        diag.setVisible(true);
    }//GEN-LAST:event_BatailleActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(JeuMemory.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(JeuMemory.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(JeuMemory.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(JeuMemory.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new JeuMemory().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JMenuItem AjoutJoueur;
    private javax.swing.JMenuItem Bataille;
    private javax.swing.JMenuItem Carte;
    private javax.swing.JTextArea Edition;
    private javax.swing.JLabel Message;
    private javax.swing.JPanel Panneau;
    private javax.swing.JLabel Restant;
    private javax.swing.JMenu Test;
    private javax.swing.JLabel Tourjoueur;
    private javax.swing.JMenuItem Transfert;
    private javax.swing.JLabel Trouve;
    private javax.swing.JButton demarrer;
    private javax.swing.JMenuBar jMenuBar1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JMenuItem joueur;
    private javax.swing.JMenuItem option;
    private javax.swing.JMenu parametres;
    private javax.swing.JButton recommencer;
    private javax.swing.JMenu visualiser;
    // End of variables declaration//GEN-END:variables
}