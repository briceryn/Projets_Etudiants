/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package JeuMemory;

/**
 *
 * @author Brice
 */
public class Bataille extends Action {
    private Joueur ad; // Joueur adverse

    // Constructeur
    public Bataille(Joueur j, Joueur ad) {
        super(j, "Bataille"); // Appel du constructeur de la classe mère (Action)
        this.ad = ad;
    }

    // Méthode pour obtenir l'adversaire
    public Joueur getAdversaire() {
        return ad;
    }

    // Méthode pour exécuter l'action
    @Override
    public int execute() {
        LesPersonnages paquetJ = getJoueurCourant().getPaquet(); // Paquet du joueur qui a déclenché l'action
        LesPersonnages paquetAd = ad.getPaquet(); // Paquet du joueur adversaire
        int result = -1; // Initialisation du résultat

        // Vérification si les deux paquets ont des cartes
        if (paquetJ.getTaille() > 0 && paquetAd.getTaille() > 0) {
            Personnage carteJ = paquetJ.getPerso(0); // Récupération de la première carte du paquet du joueur
            Personnage carteAd = paquetAd.getPerso(0); // Récupération de la première carte du paquet de l'adversaire
            paquetJ.retirePerso(0); // Retrait de la première carte du joueur
            paquetAd.retirePerso(0); // Retrait de la première carte de l'adversaire
            int valueJ = carteJ.getValeur(); // Récupération de la valeur de la carte du joueur
            int valueAd = carteAd.getValeur(); // Récupération de la valeur de la carte de l'adversaire

            // Comparaison des valeurs des cartes
            if (valueJ == valueAd) {
                result = 0; // Égalité
                paquetJ.ajoutePerso(carteJ);
                paquetAd.ajoutePerso(carteAd);
            } else {
                if (valueJ > valueAd) {
                    result = 1; // Victoire du joueur
                    paquetJ.ajoutePerso(carteAd);
                    paquetJ.ajoutePerso(carteJ);
                    paquetAd.retirePerso(carteAd);
                } else {
                    result = 2; // Victoire de l'adversaire;
                    paquetAd.ajoutePerso(carteJ);
                    paquetAd.ajoutePerso(carteAd);
                    paquetJ.retirePerso(carteJ);
                }
            }

            // Vérification s'il ne reste plus de cartes dans le paquet du joueur ou de l'adversaire
            if (paquetJ.getTaille() == 0) {
                result = -1; // Fin du jeu, victoire de l'adversaire
                setDeroulement(ad.getPseudo() + " a gagné contre " + getJoueurCourant().getPseudo());
            }
            if (paquetAd.getTaille() == 0) {
                result = -1; // Fin du jeu, victoire du joueur
                setDeroulement(getJoueurCourant().getPseudo() + " a gagné contre " + ad.getPseudo());
            }
        }
        return result; // Retourne le résultat de l'action
    }
}
