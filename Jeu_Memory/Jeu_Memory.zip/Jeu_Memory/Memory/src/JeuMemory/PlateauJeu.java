/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package JeuMemory;

/**
 *
 * @author Brice
 */
public class PlateauJeu {
    
    private int[][] TabPlateau; // plateau de jeu à  2 dimensions
    private int nbp; // nombre de personnages sur le plateau qui diminue au cours du jeu
    private int nblig; // nombre total de ligne
    private int nbcol; // nombre total de colonne 
    
    public PlateauJeu(int n) { 
        // Assignation du niveau de difficulté
        this.nbp = n;
    
        // Calcul du nombre de lignes du plateau en fonction du niveau de difficulté
        this.nblig = (int) (Math.sqrt(nbp * 2));
    
        // Calcul du nombre de colonnes du plateau en fonction du niveau de difficulté
        this.nbcol = nbp * 2 / nblig;
    
        // Initialisation du tableau représentant le plateau de jeu
        this.TabPlateau = new int[this.nblig][this.nbcol];

        // Initialisation des cases du plateau de jeu avec les personnages
        this.initPlateauJeu();
    }
    
    public PlateauJeu(){
        this(4); 
    }
/**
 * Méthode pour obtenir le nombre de lignes du plateau de jeu.
 * @return Le nombre de lignes du plateau de jeu.
 */   
    public int getNbLig() {
        return this.nblig;
    }
/**
 * Méthode pour obtenir le nombre de colonnes du plateau de jeu.
 * @return Le nombre de colonnes du plateau de jeu.
 */   
    public int getNbCol(){
        return this.nbcol;  
    }
    
    /**
     * @return nombre de personnage restant sur le plateau
     */
    public int getNbp(){   
        return this.nbp;
    }
    
 /**
 * Méthode pour définir la valeur d'une case du plateau de jeu.
 * @param l La ligne de la case.
 * @param c La colonne de la case.
 * @param value La valeur à assigner à la case.
 * @throws IndexOutOfBoundsException si les coordonnées (l, c) ne sont pas valides.
 */
    public void setCase(int l, int c, int value) {
        if (estValide(l, c)) {
            TabPlateau[l][c] = value;
        } else {
        throw new IndexOutOfBoundsException("Coordonnées invalides : (" + l + ", " + c + ")");
        }
    }

/**
 * Méthode pour Retourner la valeur d'une case du plateau de jeu.
 * @param l La ligne de la case.
 * @param c La colonne de la case.
 * @throws IndexOutOfBoundsException si les coordonnées (l, c) ne sont pas valides.
 */
    public int getCase(int l, int c){
        if(this.estValide(l, c))
            return TabPlateau[l][c];
        else
            throw new IndexOutOfBoundsException("Coordonnées invalides : (" + l + ", " + c + ")");
    }    

 /**
 * Méthode pour vérifier si les coordonnées (l, c) sont valides dans le tableau du plateau de jeu.
 * @param l La ligne.
 * @param c La colonne.
 * @return true si les coordonnées sont valides, sinon false.
 */
    private boolean estValide(int l, int c) {
        return l >= 0 && l < this.nblig && c >= 0 && c < this.nbcol;
    }
     
/**
 * Méthode pour obtenir les coordonnées (ligne, colonne) d'une case du plateau de jeu à partir de son code.
 * @param caseCoder Le code de la case.
 * @return Un tableau d'entiers contenant les coordonnées (ligne, colonne) de la case.
 */
    public int[] getCase(int caseCoder) {
        // Calcul de la ligne (l) en divisant le code de la case par le nombre de colonnes.
        int l = (int) Math.floor(caseCoder / (double) nbcol);
        // Calcul de la colonne (c) en prenant le reste de la division du code de la case par le nombre de colonnes.
        int c = caseCoder - l * nbcol;
        // Retourne un tableau contenant les coordonnées (ligne, colonne) de la case.
        return new int[]{l, c};
    }
    
    public int getCaseValue(int caseCoder) {
        int l = (int) Math.floor(caseCoder / (double) nbcol); // Calcule la ligne de la case
        int c = caseCoder - l * nbcol; // Calcule la colonne de la case
        return TabPlateau[l][c]; // Retourne la valeur de la case
    }
    
/**
 * Cette méthode renvoie le code de la case en fonction des coordonnées spécifiées.
 * 
 * @param l La coordonnée de la ligne.
 * @param c La coordonnée de la colonne.
 * @return Le code de la case, ou -1 si les coordonnées sont invalides.
 */
public int getCaseCode(int l, int c) {
    // Vérifier si les coordonnées sont valides
    if (!estValide(l, c)) {
        // Coordonnées invalides, retourner une valeur spéciale pour indiquer une erreur
        return -1;
    }
    
    // Calculer le code de la case en fonction des coordonnées l et c
    int caseCode = l * nbcol + c;
    
    return caseCode;
}
    
    //Methode pour obtenir le nombre de cartes du plateau
    public int getNbc(){
        return this.nblig*this.nbcol/2; 
    }
    
/**
 * Initialise le plateau de jeu en assignant un numéro de personnage à chaque case du plateau.
 */
    public void initPlateauJeu() {
        int k = 0;
        for (int i = 0; i < this.nblig; i++) {        
            for (int j = 0; j < this.nbcol; j++) {
                TabPlateau[i][j] = (k++) % this.nbp;
            }    
        }
        // Mélange aléatoirement les numéros de personnage sur le plateau.
        //melange();
    }

/**
 * Invalide deux cases du plateau en assignant la valeur -1 à leurs numéros de personnage
 * et décrémente le nombre de personnages restants sur le plateau.
 * @param l1 Ligne de la première case
 * @param c1 Colonne de la première case
 * @param l2 Ligne de la deuxième case
 * @param c2 Colonne de la deuxième case
 */
    public void invalide(int l1, int c1, int l2, int c2) {
        TabPlateau[l1][c1] = -1;
        TabPlateau[l2][c2] = -1;
        nbp--;
    }

/**
 * Mélange les numéros de personnage sur le plateau en échangeant aléatoirement les positions
 * de deux cases pendant un certain nombre d'itérations.
 */
    public void melange() {
        int lig1, lig2, col1, col2, case1, case2;
        for (int i = 0; i < 1000; i++) {
            lig1 = (int)(Math.random() * getNbLig());
            lig2 = (int)(Math.random() * getNbLig());
            col1 = (int)(Math.random() * getNbCol());
            col2 = (int)(Math.random() * getNbCol());
            case1 = getCase(lig1, col1);
            case2 = getCase(lig2, col2);
            setCase(lig1, col1, case2);
            setCase(lig2, col2, case1);
        }
    }

/**
 * Vérifie si le plateau de jeu est vide.
 * @return true si le plateau est vide, sinon false
 */
    public boolean jeuVide() {
        return nbp == 0;
    }
    
    public boolean estRetournee(int l, int c) {
        // Vérifier si les coordonnées sont valides
        if (!estValide(l, c)) {
            throw new IndexOutOfBoundsException("Coordonnées invalides : (" + l + ", " + c + ")");
        }
    
        // Vérifier si la case a déjà été retournée en vérifiant si son numéro de personnage est différent de -1
        return TabPlateau[l][c] != -1;
    }

/**
 * Réinitialise le plateau de jeu en assignant la valeur -1 à tous les numéros de personnage
 * et en mettant à jour le nombre de personnages restants sur le plateau.
 */
    public void termineJeu() {
        for (int i = 0; i < nblig; i++) {
            for (int j = 0; j < nbcol; j++) {
                TabPlateau[i][j] = -1;
            }
        }

    }
    
}
