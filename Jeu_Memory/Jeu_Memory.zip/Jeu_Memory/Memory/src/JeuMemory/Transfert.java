/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package JeuMemory;

/**
 *
 * @author Brice
 */
public class Transfert extends Action {
    private Joueur jCible; // Joueur cible du transfert
    private LesPersonnages cartesTransferees; // Liste des personnages transférés
    private String fp; // Famille de personnages à transférer

    private final static String descAction = "Transfert de cartes"; // Description de l'action

    /**
     * Constructeur de la classe Transfert.
     * @param jCourant Le joueur courant qui effectue le transfert.
     * @param jCible Le joueur cible du transfert.
     * @param fp La famille de personnages à transférer.
     */
    public Transfert(Joueur jCourant, Joueur jCible, String fp) {
        super(jCourant, descAction);
        this.jCible = jCible;
        this.fp = fp;
    }

    /**
     * Obtient le joueur courant qui effectue le transfert.
     * @return Le joueur courant.
     */
    public Joueur getjCourant() {
        return super.getJoueurCourant();
    }

    /**
     * Obtient le joueur cible du transfert.
     * @return Le joueur cible.
     */
    public Joueur getJoueurCible() {
        return jCible;
    }

    /**
     * Obtient la liste des personnages transférés.
     * @return La liste des personnages transférés.
     */
    public LesPersonnages getCartesTransferees() {
        return cartesTransferees;
    }

    /**
     * Exécute l'action de transfert.
     * @return Le nombre de cartes transférées, ou 0 si aucun transfert n'a été effectué.
     */
    @Override
    public int execute() {
        if (fp != null) { // Vérifie si la famille de personnages à transférer est spécifiée
            cartesTransferees = jCible.getPaquet().getPersosFamille(fp); // Récupère la liste des personnages à transférer
            jCible.getPaquet().retirePersosFamille(fp); // Retire les personnages du paquet du joueur cible
            getjCourant().getPaquet().ajoutePersos(cartesTransferees); // Ajoute les personnages au paquet du joueur courant
            super.setDeroulement(getjCourant().getPseudo() + " a pris la famille " + fp + " à " + jCible.getPseudo()); // Définit le déroulement de l'action
            return cartesTransferees.getTaille(); // Retourne le nombre de cartes transférées
        } else {
            return 0; // Retourne 0 si aucune famille de personnages à transférer n'est spécifiée
        }
    }
}