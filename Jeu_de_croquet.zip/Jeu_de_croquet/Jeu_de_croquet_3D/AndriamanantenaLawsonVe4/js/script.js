const borneVue=12;//amplitude de deplacement de la camera

function init(){
    var stats = initStats();
       // creation de rendu et de la taille
    let rendu = new THREE.WebGLRenderer({ antialias: true });
    rendu.shadowMap.enabled = true;
    let scene = new THREE.Scene();   
    let result;
    let camera = new THREE.PerspectiveCamera(20, window.innerWidth / window.innerHeight, 0.1, 100);
    rendu.shadowMap.enabled = true;
    rendu.setClearColor(new THREE.Color(0xFFFFFF));
    rendu.setSize(window.innerWidth*.9, window.innerHeight*.9);
    cameraLumiere(scene,camera);
    lumiere(scene);
    repere(scene);
    //x rouge, y vert, z bleue
    
    //plan du sol
     const largPlan = 75;
     const hautPlan = 75;
     const nbSegmentLarg = 30;
     const nbSegmentHaut = 30;
     const PlanSolGeometry = new THREE.PlaneGeometry(largPlan,hautPlan,nbSegmentLarg,nbSegmentHaut);
     const PlanSol = surfPhong(PlanSolGeometry,"#00EB00",1,true,"#00EB00");
     PlanSol.position.z = 0;
     PlanSol.receiveShadow = true; 
     PlanSol.castShadow = true;
     scene.add(PlanSol);
   // fin du plan du sol
    let vecz= new THREE.Vector3(0,0,1);
    let vecx= new THREE.Vector3(1,0,0);
    let vecy= new THREE.Vector3(0,1,0);


    //********************************************************
    //
    //  D E B U T     J E U
    //
    //********************************************************
    //demande le mode joueur et initialisation des trajet
    let alea1;
    let alea2;
    let alea3;
    alea1=1;
    alea2=1;
    alea3=1;
    do{
    n=parseInt(prompt("1/debutant 2/expert"));
      if(n==1){
        alea1= Math.floor(Math.random() * 2) + 1;
        alea2=Math.floor(Math.random() * 2) + 1;
        alea3=Math.floor(Math.random() * 2) + 1;
      }
      else if(n==2){
        alea1=1;
        alea2=1;
        alea3=1;
      }
    }while(n!=1&&n!=2);
    //fin de la demande de mode du joueur
    //********************************************************
    //
    //  F I N     J E U
    //
    //********************************************************




    //********************************************************
    //
    //  D E B U T     G E O
    //
    //********************************************************
    //matériel Phong des montant des arceaux
    let montantPhong= new THREE.MeshPhongMaterial({
      color: '#FF0000',
      opacity: 1,
      transparent: false,
      wireframe: false,
      emissive:0x000000,
      specular:"#00FFFF", 
      flatShading: true,
      shininess:30,
      side: THREE.DoubleSide,
    });
    //matériel Phong de la partie horizontal des arceaux
    let restePhong= new THREE.MeshPhongMaterial({
      color: '#FF0000',
      opacity: 1,
      transparent: false,
      wireframe: false,
      emissive:0x000000,
      specular:"#00FFFF", 
      flatShading: true,
      shininess:30,
      side: THREE.DoubleSide,
    });

    //initialisation des données des arceaux
    //taille des lathes
    let V1=new THREE.Vector3(0.25,0.5,0);
    let V2=new THREE.Vector3(0.125,2.25,0);
    let V3=new THREE.Vector3(0.25,3.5,0);
    //nombres des points des lathes
    let nbPts1=10;
    let nbPts2=10;
    let nbPts3=10;
    let nbPts4=10;
    let nbPts5=10;
    let nbPts6=10;
    //coefficients de jointure G1 des lathes
    let coef1=0.5;
    let coef2=0.5;
    //fin initialisation des données

    //création des arceaux
    A1=arceaux(nbPts1,nbPts2,nbPts3,nbPts4,nbPts5,nbPts6,V1,V2,V3,coef1,coef2,4,0,montantPhong,restePhong)
    A2=arceaux(nbPts1,nbPts2,nbPts3,nbPts4,nbPts5,nbPts6,V1,V2,V3,coef1,coef2,7,3,montantPhong,restePhong)
    A3=arceaux(nbPts1,nbPts2,nbPts3,nbPts4,nbPts5,nbPts6,V1,V2,V3,coef1,coef2,-10,5,montantPhong,restePhong) 
    A2.rotateOnAxis(vecz,Math.PI/2)
    A3.rotateOnAxis(vecz,Math.PI/2)
    A1.castShadow=true;
    A2.castShadow=true;
    A3.castShadow=true;
    scene.add(A1);
    scene.add(A2);
    scene.add(A3);
    //fin création des arceaux

    //création de la balle
    let balleGeom = new THREE.SphereGeometry(0.5, 160, 60);
    let Phongball = new THREE.MeshPhongMaterial({
    color: "#ff8000",//orange
    opacity: 1,
    transparent: true,
    wireframe: false,
    emissive:0x000000,
    specular:"#00FFFF", 
    flatShading: true,
    shininess:30,
    side: THREE.DoubleSide,
    });
    let balle = new THREE.Mesh(balleGeom,Phongball);
    balle.castShadow= true;
    balle.receiveShadow=true;
    balle.translateZ(0.5)
    balle.translateX(2.5)
    balle.translateY(-2.5)
    scene.add(balle);
    //fin de la création de la balle

    //création du maillet
    let groupe= new THREE.Group();
    //création du marteaux 1
    let rayon1 = 0.5 ;
    let rayon2 = -0.5 ;
    let hauteur = 3 ;
    let nbePtsCercle = 60 ;
    let nbePtsGenera = 2 ;
    let bolOuvert = false ;
    let theta0 = 0 ;
    let thetaLg = 2*Math.PI ;
    let CylConeGeom = new THREE.CylinderGeometry(rayon1,rayon2,hauteur,nbePtsCercle, nbePtsGenera, bolOuvert,theta0, thetaLg );
    let CylPhong = new THREE.MeshPhongMaterial({
        color: "#008B8B", // cyan fonce
          opacity: 0.75,
          transparent: false,
          emissive:0x000000, //couleur emissive
          specular:"#00FFFF", //couleur speculaire
          flatShading: false,
          shininess:30,//brillance
          side: THREE.DoubleSide,
        });
    let Sablier = new THREE.Mesh(CylConeGeom ,CylPhong);
    Sablier.translateZ(1)
    Sablier.translateY(-2.2)
    Sablier.translateX(0.5)
    Sablier.rotateOnAxis(vecz,Math.PI/1.8)
    Sablier.rotateOnAxis(vecy,Math.PI/2)
    groupe.add(Sablier)
    //fin création du marteaux 1

    //création du manche
    let batte=prisme(4,0.25,4);
    batte.translateX(0.5)
    batte.translateY(-2.2);
    batte.translateZ(1)
    batte.rotateOnAxis(vecy,-Math.PI)
    groupe.add(batte)
    //fin création du manche

    //création du marteaux 2
    let marteau=prisme(2.5,0.75,50)
    marteau.rotateOnAxis(vecy,Math.PI/2)
    marteau.translateX(-1)
    marteau.translateY(-2.2)
    marteau.translateZ(-1)
    marteau.rotateOnAxis(vecz,Math.PI)
    //groupe.add(marteau)
    //fin création du marteaux 2

    groupe.castShadow=true;
    groupe.receiveShadow=true;
    groupe.translateZ(2)
    groupe.translateX(1)
    groupe.rotateOnAxis(vecy,-Math.PI/4)
    scene.add(groupe)
    //fin création du maillet
    
    //création demi-cone
    let R1 = 1.5 ;
    let R2 = 0 ;
    let H = 3 ;
    let nbePtsCercle2 = 60 ;
    let nbePtsGenera2 = 2 ;
    let bolOuvert2 = true ;
    let theta02 = 0 ;
    let thetaLg2 = Math.PI ;
    let ConeGeom = new THREE.CylinderGeometry(R1,R2,H,nbePtsCercle2, nbePtsGenera2, bolOuvert2,theta02, thetaLg2 );
    let ConePhong = new THREE.MeshPhongMaterial({
        color: "#FFFFE0", // couleur de l’objet
          opacity: 0.75,
          transparent: true,
          emissive:0x000000, //couleur emissive
          specular:"#00FFFF", //couleur speculaire
          flatShading: true,
          shininess:30,//brillance
          side: THREE.DoubleSide,
        });
    let Cone = new THREE.Mesh(ConeGeom ,ConePhong);
    Cone.rotateOnAxis(vecy,-Math.PI/2)
    Cone.rotateOnAxis(vecx,Math.PI/2)
    Cone.position.y=-9
    Cone.position.x=-1
    scene.add(Cone);
    //fin création demi-cone

    //********************************************************
    //
    //  F I N      G E O
    //
    //********************************************************
    
    //********************************************************
    //
    //  D E B U T     M E N U     G U I
    //
    //********************************************************
    var gui = new dat.GUI();//interface graphique utilisateur
     // ajout du menu dans le GUI
    let menuGUI = new function () {
      this.cameraxPos = camera.position.x;
      this.camerayPos = camera.position.y;
      this.camerazPos = camera.position.z;
      this.cameraZoom = 3.5;
      //pb avec camera lockAt
      this.cameraxDir = 0;//camera.getWorldDirection().x;
      this.camerayDir = 0;//camera.getWorldDirection().y;
      this.camerazDir = 0;//camera.getWorldDirection().z;
      //this.choixCbe=1;
      //this.NbrePts=40;
      this.AffichageArceaux = true;//.visible;
      //Propriétés lumineuses des montants Phong
      this.CouleurPhong = "Rouge"//couleur
      this.opacitePhong = montantPhong.opacity;//opacité
      this.emissivePhong = montantPhong.emissive.getHex();//emissivité
      this.specularPhong = montantPhong.specular.getStyle();//speculaire
      this.brillancePhong = montantPhong.shininess;//briance
      if (montantPhong.flatShading)//lissage
        this.lissage = 'Oui';
      else this.lissage = 'Non';
      switch (montantPhong.side){//cotés vus
        case 1 : this.faces = 'Avant'; break;
        case 0 : this.faces = 'Arriere'; break;
        case 2 : this.faces = 'DeuxFaces';
      }
      this.tete="Sablier"//tete du maillet
      //Points de controles des lathes 
      this.P1X=V1.x;
      this.P1Y=V1.y;
      this.nbrdepointscercle1=nbPts1;
      this.nbrdepointscourbe1=nbPts4;

      this.P2X=V2.x;
      this.P2Y=V2.y;
      this.nbrdepointscercle2=nbPts2;
      this.nbrdepointscourbe2=nbPts5;

      this.P3X=V3.x;
      this.P3Y=V3.y;
      this.nbrdepointscercle3=nbPts3;
      this.nbrdepointscourbe3=nbPts6;
      //coefficient de jointures des lathes
      this.c1=coef1;
      this.c2=coef2;

      //pour actualiser dans la scene   
      this.actualisation = function () {
       posCamera();
       reAffichage();
      }; // fin this.actualisation
    }; // fin de la fonction menuGUI
    // ajout de la camera dans le menu
    ajoutCameraGui(gui,menuGUI,camera)

    // ajout de spherePhong dans le menu du GUI
    let guiArceauxPhong = gui.addFolder("Arceaux : Phong"); 
    // Affichage arceaux
    gui.add(menuGUI,'AffichageArceaux').onChange(function (e) {
      if (!e) {scene.remove(A1); scene.remove(A2); scene.remove(A3);}  
      else{
        scene.add(A1); 
        scene.add(A2); 
        scene.add(A3);
      }           
    });//fin cochage  Phong
 
          
    //emissivite
    guiArceauxPhong.addColor(menuGUI,'emissivePhong').onChange(function (e) {
      montantPhong.emissive= new THREE.Color(e);
      });
    //specularPhong
    guiArceauxPhong.addColor(menuGUI,'specularPhong').onChange(function (e) {
      montantPhong.specular= new THREE.Color(e);
      });
    //brillance
    guiArceauxPhong.add(menuGUI,'brillancePhong',0,200).onChange(function (e) {
      montantPhong.shininess = e;
      });
    //lissage 
    guiArceauxPhong.add(menuGUI,'lissage',['Oui','Non']).onChange(function (e) {
      if (e=='Oui') 
        montantPhong.flatShading = true;
      else montantPhong.flatShading = false; 
      });
    //opacity
    guiArceauxPhong.add(menuGUI,'opacitePhong',0,1).onChange(function (e) {
      montantPhong.opacity=e;
      }); 
    //face   
    guiArceauxPhong.add(menuGUI,'faces',['Avant','Arriere','DeuxFaces']).onChange(function (e) {
      if (e=='Avant') 
        montantPhong.side=1;
      else if (e=='Arriere') 
        montantPhong.side=0;
      else montantPhong.side=2;
      }); 

    //menu Gui tete marteau
    let guiMarteau = gui.addFolder("Maillet : Tete");
    //change la tete du marteau
    guiMarteau.add(menuGUI,'tete',['Sablier','Prisme']).onChange(function (e) {
      if (e=='Sablier') {
        scene.remove(groupe); 
        groupe.remove(marteau);
        groupe.add(Sablier);
        scene.add(groupe)}  
      else{
        scene.remove(groupe); 
        groupe.remove(Sablier);
        groupe.add(marteau);
        scene.add(groupe)
      }           
    });
    
    //menu Gui pour la couleurs des arceaux
    let guiColor  = gui.addFolder("Couleur"); 
    // couleur
    guiColor.add(menuGUI,'CouleurPhong',['Rouge','Bleu','Vert','Magenta']).onChange(function (e) {
      if(e=='Rouge'){
        montantPhong.color.setStyle('#FF0000');
        restePhong.color.setStyle('#FF0000');
      }
      if(e=='Bleu'){
        montantPhong.color.setStyle('#0000FF');
        restePhong.color.setStyle('#0000FF');
      }
      if(e=='Vert'){
        montantPhong.color.setStyle('#00FF00');
        restePhong.color.setStyle('#00FF00');
      }
      if(e=='Magenta'){
        montantPhong.color.setStyle('#FF00FF');
        restePhong.color.setStyle('#FF00FF');
      }
      });

    //menu Gui points de controles lathe 
    let guicourbe = gui.addFolder("Lathe ");
    
    guicourbe.add(menuGUI,'P1X',0,5).step(0.25).onChange(function(e){
      scene.remove(A1); 
      scene.remove(A2); 
      scene.remove(A3);
      V1=new THREE.Vector3(e,V1.y,V1.z);
      A1=arceaux(nbPts1,nbPts2,nbPts3,nbPts4,nbPts5,nbPts6,V1,V2,V3,coef1,coef2,4,0,montantPhong,restePhong)
      A2=arceaux(nbPts1,nbPts2,nbPts3,nbPts4,nbPts5,nbPts6,V1,V2,V3,coef1,coef2,7,3,montantPhong,restePhong)
      A3=arceaux(nbPts1,nbPts2,nbPts3,nbPts4,nbPts5,nbPts6,V1,V2,V3,coef1,coef2,-10,5,montantPhong,restePhong) 
      A2.rotateOnAxis(vecz,Math.PI/2)
      A3.rotateOnAxis(vecz,Math.PI/2)
      scene.add(A1);
      scene.add(A2);
      scene.add(A3);
    });
    guicourbe.add(menuGUI,'P1Y',0,5).step(0.25).onChange(function(e){
      scene.remove(A1); 
      scene.remove(A2); 
      scene.remove(A3);
      V1=new THREE.Vector3(V1.x,e,V1.z);
      A1=arceaux(nbPts1,nbPts2,nbPts3,nbPts4,nbPts5,nbPts6,V1,V2,V3,coef1,coef2,4,0,montantPhong,restePhong)
      A2=arceaux(nbPts1,nbPts2,nbPts3,nbPts4,nbPts5,nbPts6,V1,V2,V3,coef1,coef2,7,3,montantPhong,restePhong)
      A3=arceaux(nbPts1,nbPts2,nbPts3,nbPts4,nbPts5,nbPts6,V1,V2,V3,coef1,coef2,-10,5,montantPhong,restePhong) 
      A2.rotateOnAxis(vecz,Math.PI/2)
      A3.rotateOnAxis(vecz,Math.PI/2)
      scene.add(A1);
      scene.add(A2);
      scene.add(A3);
    });
    guicourbe.add(menuGUI,'nbrdepointscercle1',['5','10','25','50']).onChange(function(e){
      scene.remove(A1); 
      scene.remove(A2); 
      scene.remove(A3);
      nbPts1=e;
      A1=arceaux(nbPts1,nbPts2,nbPts3,nbPts4,nbPts5,nbPts6,V1,V2,V3,coef1,coef2,4,0,montantPhong,restePhong)
      A2=arceaux(nbPts1,nbPts2,nbPts3,nbPts4,nbPts5,nbPts6,V1,V2,V3,coef1,coef2,7,3,montantPhong,restePhong)
      A3=arceaux(nbPts1,nbPts2,nbPts3,nbPts4,nbPts5,nbPts6,V1,V2,V3,coef1,coef2,-10,5,montantPhong,restePhong) 
      A2.rotateOnAxis(vecz,Math.PI/2)
      A3.rotateOnAxis(vecz,Math.PI/2)
      scene.add(A1);
      scene.add(A2);
      scene.add(A3);
    });
    guicourbe.add(menuGUI,'nbrdepointscourbe1',['5','10','25','50']).onChange(function(e){
      scene.remove(A1); 
      scene.remove(A2); 
      scene.remove(A3);
      nbPts4=e;
      A1=arceaux(nbPts1,nbPts2,nbPts3,nbPts4,nbPts5,nbPts6,V1,V2,V3,coef1,coef2,4,0,montantPhong,restePhong)
      A2=arceaux(nbPts1,nbPts2,nbPts3,nbPts4,nbPts5,nbPts6,V1,V2,V3,coef1,coef2,7,3,montantPhong,restePhong)
      A3=arceaux(nbPts1,nbPts2,nbPts3,nbPts4,nbPts5,nbPts6,V1,V2,V3,coef1,coef2,-10,5,montantPhong,restePhong) 
      A2.rotateOnAxis(vecz,Math.PI/2)
      A3.rotateOnAxis(vecz,Math.PI/2)
      scene.add(A1);
      scene.add(A2);
      scene.add(A3);
    });

    

    guicourbe.add(menuGUI,'P2X',0,5).step(0.25).onChange(function(e){
      scene.remove(A1); 
      scene.remove(A2); 
      scene.remove(A3);
      V2=new THREE.Vector3(e,V2.y,V2.z);
      A1=arceaux(nbPts1,nbPts2,nbPts3,nbPts4,nbPts5,nbPts6,V1,V2,V3,coef1,coef2,4,0,montantPhong,restePhong)
      A2=arceaux(nbPts1,nbPts2,nbPts3,nbPts4,nbPts5,nbPts6,V1,V2,V3,coef1,coef2,7,3,montantPhong,restePhong)
      A3=arceaux(nbPts1,nbPts2,nbPts3,nbPts4,nbPts5,nbPts6,V1,V2,V3,coef1,coef2,-10,5,montantPhong,restePhong) 
      A2.rotateOnAxis(vecz,Math.PI/2)
      A3.rotateOnAxis(vecz,Math.PI/2)
      scene.add(A1);
      scene.add(A2);
      scene.add(A3);
    });
    guicourbe.add(menuGUI,'P2Y',0,5).step(0.25).onChange(function(e){
      scene.remove(A1); 
      scene.remove(A2); 
      scene.remove(A3);
      V2=new THREE.Vector3(V2.x,e,V2.z);
      A1=arceaux(nbPts1,nbPts2,nbPts3,nbPts4,nbPts5,nbPts6,V1,V2,V3,coef1,coef2,4,0,montantPhong,restePhong)
      A2=arceaux(nbPts1,nbPts2,nbPts3,nbPts4,nbPts5,nbPts6,V1,V2,V3,coef1,coef2,7,3,montantPhong,restePhong)
      A3=arceaux(nbPts1,nbPts2,nbPts3,nbPts4,nbPts5,nbPts6,V1,V2,V3,coef1,coef2,-10,5,montantPhong,restePhong) 
      A2.rotateOnAxis(vecz,Math.PI/2)
      A3.rotateOnAxis(vecz,Math.PI/2)
      scene.add(A1);
      scene.add(A2);
      scene.add(A3);
    });
    guicourbe.add(menuGUI,'nbrdepointscercle2',['5','10','25','50']).onChange(function(e){
      scene.remove(A1); 
      scene.remove(A2); 
      scene.remove(A3);
      nbPts2=e;
      A1=arceaux(nbPts1,nbPts2,nbPts3,nbPts4,nbPts5,nbPts6,V1,V2,V3,coef1,coef2,4,0,montantPhong,restePhong)
      A2=arceaux(nbPts1,nbPts2,nbPts3,nbPts4,nbPts5,nbPts6,V1,V2,V3,coef1,coef2,7,3,montantPhong,restePhong)
      A3=arceaux(nbPts1,nbPts2,nbPts3,nbPts4,nbPts5,nbPts6,V1,V2,V3,coef1,coef2,-10,5,montantPhong,restePhong)
      A2.rotateOnAxis(vecz,Math.PI/2)
      A3.rotateOnAxis(vecz,Math.PI/2)
      scene.add(A1);
      scene.add(A2);
      scene.add(A3);
    });
    guicourbe.add(menuGUI,'nbrdepointscourbe2',['5','10','25','50']).onChange(function(e){
      scene.remove(A1); 
      scene.remove(A2); 
      scene.remove(A3);
      nbPts5=e;
      A1=arceaux(nbPts1,nbPts2,nbPts3,nbPts4,nbPts5,nbPts6,V1,V2,V3,coef1,coef2,4,0,montantPhong,restePhong)
      A2=arceaux(nbPts1,nbPts2,nbPts3,nbPts4,nbPts5,nbPts6,V1,V2,V3,coef1,coef2,7,3,montantPhong,restePhong)
      A3=arceaux(nbPts1,nbPts2,nbPts3,nbPts4,nbPts5,nbPts6,V1,V2,V3,coef1,coef2,-10,5,montantPhong,restePhong) 
      A2.rotateOnAxis(vecz,Math.PI/2)
      A3.rotateOnAxis(vecz,Math.PI/2)
      scene.add(A1);
      scene.add(A2);
      scene.add(A3);
    });

    
    guicourbe.add(menuGUI,'P3X',0,5).step(0.25).onChange(function(e){
      scene.remove(A1); 
      scene.remove(A2); 
      scene.remove(A3);
      V3=new THREE.Vector3(e,V3.y,V3.z);
      A1=arceaux(nbPts1,nbPts2,nbPts3,nbPts4,nbPts5,nbPts6,V1,V2,V3,coef1,coef2,4,0,montantPhong,restePhong)
      A2=arceaux(nbPts1,nbPts2,nbPts3,nbPts4,nbPts5,nbPts6,V1,V2,V3,coef1,coef2,7,3,montantPhong,restePhong)
      A3=arceaux(nbPts1,nbPts2,nbPts3,nbPts4,nbPts5,nbPts6,V1,V2,V3,coef1,coef2,-10,5,montantPhong,restePhong) 
      A2.rotateOnAxis(vecz,Math.PI/2)
      A3.rotateOnAxis(vecz,Math.PI/2)
      scene.add(A1);
      scene.add(A2);
      scene.add(A3);
    });
    guicourbe.add(menuGUI,'P3Y',0,5).step(0.25).onChange(function(e){
      scene.remove(A1); 
      scene.remove(A2); 
      scene.remove(A3);
      V3=new THREE.Vector3(V3.x,e,V3.z);
      A1=arceaux(nbPts1,nbPts2,nbPts3,nbPts4,nbPts5,nbPts6,V1,V2,V3,coef1,coef2,4,0,montantPhong,restePhong)
      A2=arceaux(nbPts1,nbPts2,nbPts3,nbPts4,nbPts5,nbPts6,V1,V2,V3,coef1,coef2,7,3,montantPhong,restePhong)
      A3=arceaux(nbPts1,nbPts2,nbPts3,nbPts4,nbPts5,nbPts6,V1,V2,V3,coef1,coef2,-10,5,montantPhong,restePhong)  
      A2.rotateOnAxis(vecz,Math.PI/2)
      A3.rotateOnAxis(vecz,Math.PI/2)
      scene.add(A1);
      scene.add(A2);
      scene.add(A3);
    });
    guicourbe.add(menuGUI,'nbrdepointscercle3',['5','10','25','50']).onChange(function(e){
      scene.remove(A1); 
      scene.remove(A2); 
      scene.remove(A3);
      nbPts3=e;
      A1=arceaux(nbPts1,nbPts2,nbPts3,nbPts4,nbPts5,nbPts6,V1,V2,V3,coef1,coef2,4,0,montantPhong,restePhong)
      A2=arceaux(nbPts1,nbPts2,nbPts3,nbPts4,nbPts5,nbPts6,V1,V2,V3,coef1,coef2,7,3,montantPhong,restePhong)
      A3=arceaux(nbPts1,nbPts2,nbPts3,nbPts4,nbPts5,nbPts6,V1,V2,V3,coef1,coef2,-10,5,montantPhong,restePhong)  
      A2.rotateOnAxis(vecz,Math.PI/2)
      A3.rotateOnAxis(vecz,Math.PI/2)
      scene.add(A1);
      scene.add(A2);
      scene.add(A3);
    });
    guicourbe.add(menuGUI,'nbrdepointscourbe3',['5','10','25','50']).onChange(function(e){
      scene.remove(A1); 
      scene.remove(A2); 
      scene.remove(A3);
      nbPts6=e;
      A1=arceaux(nbPts1,nbPts2,nbPts3,nbPts4,nbPts5,nbPts6,V1,V2,V3,coef1,coef2,4,0,montantPhong,restePhong)
      A2=arceaux(nbPts1,nbPts2,nbPts3,nbPts4,nbPts5,nbPts6,V1,V2,V3,coef1,coef2,7,3,montantPhong,restePhong)
      A3=arceaux(nbPts1,nbPts2,nbPts3,nbPts4,nbPts5,nbPts6,V1,V2,V3,coef1,coef2,-10,5,montantPhong,restePhong) 
      A2.rotateOnAxis(vecz,Math.PI/2)
      A3.rotateOnAxis(vecz,Math.PI/2)
      scene.add(A1);
      scene.add(A2);
      scene.add(A3);
    });

    
    guicourbe.add(menuGUI,'c1',-10,10).step(0.25).onChange(function(e){
      scene.remove(A1); 
      scene.remove(A2); 
      scene.remove(A3);
      coef1=e;
      A1=arceaux(nbPts1,nbPts2,nbPts3,nbPts4,nbPts5,nbPts6,V1,V2,V3,coef1,coef2,4,0,montantPhong,restePhong)
      A2=arceaux(nbPts1,nbPts2,nbPts3,nbPts4,nbPts5,nbPts6,V1,V2,V3,coef1,coef2,7,3,montantPhong,restePhong)
      A3=arceaux(nbPts1,nbPts2,nbPts3,nbPts4,nbPts5,nbPts6,V1,V2,V3,coef1,coef2,-10,5,montantPhong,restePhong)  
      A2.rotateOnAxis(vecz,Math.PI/2)
      A3.rotateOnAxis(vecz,Math.PI/2)
      scene.add(A1);
      scene.add(A2);
      scene.add(A3);
    });
    guicourbe.add(menuGUI,'c2',-10,10).step(0.25).onChange(function(e){
      scene.remove(A1); 
      scene.remove(A2); 
      scene.remove(A3);
      coef2=e;
      A1=arceaux(nbPts1,nbPts2,nbPts3,nbPts4,nbPts5,nbPts6,V1,V2,V3,coef1,coef2,4,0,montantPhong,restePhong)
      A2=arceaux(nbPts1,nbPts2,nbPts3,nbPts4,nbPts5,nbPts6,V1,V2,V3,coef1,coef2,7,3,montantPhong,restePhong)
      A3=arceaux(nbPts1,nbPts2,nbPts3,nbPts4,nbPts5,nbPts6,V1,V2,V3,coef1,coef2,-10,5,montantPhong,restePhong) 
      A2.rotateOnAxis(vecz,Math.PI/2)
      A3.rotateOnAxis(vecz,Math.PI/2)
      scene.add(A1);
      scene.add(A2);
      scene.add(A3);
    });

    //ajout du menu pour actualiser l'affichage 
    gui.add(menuGUI, "actualisation");
    menuGUI.actualisation();
    gui.close();
    //********************************************************
    //
    //  F I N     M E N U     G U I
    //
    //********************************************************

    //********************************************************
    //
    //  D E B U T     C O U R B E S 
    //
    //********************************************************
      
      
      //point de controle du trajet1
      let t12= new THREE.Vector3(14,3,0);
      let t11= new THREE.Vector3(2,-2.5,0);

      //point de controle du trajet2
      let t22 = new THREE.Vector3(0,11,0);
      let t23 = new THREE.Vector3(-5,11,0);
      


      //point de controle du trajet3
      let t32= new THREE.Vector3(-14,9,0);
      let t33=new THREE.Vector3(-16,7,0);
      let t34=new THREE.Vector3(-17,4,0);
      

      //point de controle du trajet4
      let t42=new THREE.Vector3(-8,-6,0);
      let t43=new THREE.Vector3(-2,-9,0);

      //point de controle du trajet5
      let t52= new THREE.Vector3(16,-2,0);
      let t53=new THREE.Vector3(15,-7,0);

      //point de controle du trajet6
      let t63=new THREE.Vector3(-1,13,0);
      let t64=new THREE.Vector3(-8,20,0);

      //point de controle du trajet7
      let t73=new THREE.Vector3(-14,6,0);
      let t74=new THREE.Vector3(-17,4,0);
      let t75=new THREE.Vector3(-0,-5,0);


      //les jointures entres les trajets
      let G11=new THREE.Vector3(t22.x-t12.x,t22.y-t12.y,t22.z-t12.z);
      G11=new THREE.Vector3(t12.x+((G11.x)*0.5),t12.y+((G11.y)*0.5),t12.z+((G11.z)*0.5));
      let G12=new THREE.Vector3(t32.x-t23.x,t32.y-t23.y,t32.z-t23.z);
      G12=new THREE.Vector3(t23.x+((G12.x)*0.5),t23.y+((G12.y)*0.5),t23.z+((G12.z)*0.5));
      let G13=new THREE.Vector3(t42.x-t34.x,t42.y-t34.y,t42.z-t34.z);
      G13=new THREE.Vector3(t34.x+((G13.x)*0.5),t34.y+((G13.y)*0.5),t34.z+((G13.z)*0.5));


      //representation des trajets dans la scene
      let imagetraje1=courbedeg2(t11,t12,G11,10);
      scene.add(imagetraje1)
      let imagetrajet2=courbedeg3(G11, t22, t23, G12);
      scene.add(imagetrajet2)
      let pointBez=[G12,t32,t33,t34,G13];
      let bez4=traceBezierTab(pointBez,10,'#7F00FF',0.5)
      scene.add(bez4)
      let imagetraje4=courbedeg2(G13,t42,t43,10);
      scene.add(imagetraje4)
      let imagetrajet5=courbedeg2(t11,t52,t53,10);
      scene.add(imagetrajet5);
      let imagetrajet6=courbedeg3(G11, t22, t63, t64);
      scene.add(imagetrajet6)
      let pointBez2=[G12,t32,t73,t74,t75];
      let bez42=traceBezierTab(pointBez2,10,'#7F00FF',0.5)
      scene.add(bez42)

      //creation des trajet
      let trajet1=new THREE.QuadraticBezierCurve3(t11, t12, G11 );//degrée 2
      let trajet2=new THREE.CubicBezierCurve3(G11, t22, t23, G12);//degrée 3
      let trajet3=BezTab(scene,100,pointBez,'#7F00FF',0.5);//degrée 4
      let trajet4=new THREE.QuadraticBezierCurve3(G13,t42,t43 );//degrée 2
      let trajet5=new THREE.QuadraticBezierCurve3(t11, t52, t53 );//degrée 2
      let trajet6=new THREE.CubicBezierCurve3(G11, t22, t63, t64);//degrée 3
      let trajet7=BezTab(scene,100,pointBez2,'#7F00FF',0.5);//degrée 4


    //********************************************************
    //
    //  F I N     C O U R B E S
    //
    //********************************************************


    renduAnim();
    
     // definition des fonctions idoines
    function posCamera(){
     camera.position.set(menuGUI.cameraxPos*testZero(menuGUI.cameraZoom),menuGUI.camerayPos*testZero(menuGUI.cameraZoom),menuGUI.camerazPos*testZero(menuGUI.cameraZoom));
     camera.lookAt(menuGUI.cameraxDir,menuGUI.camerayDir,menuGUI.camerazDir);
     actuaPosCameraHTML();
    }
    
    function actuaPosCameraHTML(){
     document.forms["controle"].PosX.value=testZero(menuGUI.cameraxPos);
     document.forms["controle"].PosY.value=testZero(menuGUI.camerayPos);
     document.forms["controle"].PosZ.value=testZero(menuGUI.camerazPos); 
     document.forms["controle"].DirX.value=testZero(menuGUI.cameraxDir);
     document.forms["controle"].DirY.value=testZero(menuGUI.camerayDir);
     document.forms["controle"].DirZ.value=testZero(menuGUI.camerazDir);
    } // fin fonction posCamera
     // ajoute le rendu dans l'element HTML
    document.getElementById("webgl").appendChild(rendu.domElement);
      
     // affichage de la scene
    rendu.render(scene, camera);
     
    let i=0;//compteur des trajectoirs de degrée inférieurs ou égale à 3 
    let phase1=10;//premier mouvement du maillet
    let phase2=11;//deuxième mouvement du maillet
    let phase3=11;//troisième mouvement du maillet
    let j=0;//compteur des trajectoirs de degrée supérieur à 3 
    let y;//position en y de la camera durant le mouvement de la balle
    let x;//position en x de la camera durant le mouvement de la balle
    function reAffichage() {
     setTimeout(function () {
      //scene.remove(A1); scene.remove(A2); scene.remove(A3);
      posCamera();
      //scene.add(A1); scene.add(A2); scene.add(A3);
      if(phase1>=5){//premièr phase de l'animation
        groupe.rotateOnAxis(vecy,-Math.PI/phase1)//premièr rotation du maillet
        phase1-=1;
        reAffichage();
      }
      else{//recupération des points de chaque trajet
        if(alea1==1){
          var point=trajet1.getPointAt(i);
        }
        if(alea1==2){
          var point=trajet5.getPointAt(i);
        }
        if(alea2==1){
          var point2=trajet2.getPointAt(i-1);
        }
        if(alea2==2){
          var point2=trajet6.getPointAt(i-1);
        }
        if(alea3==1){
          var point3=trajet3[j];
        }
        if(alea3==2){
          var point3=trajet7[j];
        }
      
      var point4=trajet4.getPointAt(i-2);
      var pointfinal=trajet4.getPointAt(1);
      //scene.add(balle);
      if(i<=1){//premier mouvement de la balle
        i+=0.1;//vitesse de deplacement de balle
        balle.position.set(point.x, point.y, 0.5)//deplacement de la balle
        y=balle.position.y-10;
        camera.position.y=y;//repositionnement de la camera suivant la trajectoire de la balle
        camera.lookAt(balle.position.x,balle.position.y,balle.position.z)
        reAffichage();
      }
      else if(alea1==1){
        if(phase2==11){//deuxième phase de l'animation
        camera.position.x=0;
        camera.position.y=50;//deplacement de la camera
        camera.lookAt(balle.position.x,balle.position.y,balle.position.z)
        groupe.rotateOnAxis(vecz,-Math.PI)//changement de place du maillet
        groupe.position.set(balle.position.x+1,balle.position.y-2.5,balle.position.z+1.5)
        groupe.rotateOnAxis(vecy,Math.PI/1.5)
        phase2=10;
        reAffichage();
        }
        else{
          if(phase2>=6){
            camera.position.x=0//fixer la camera
            camera.position.y=50
            camera.lookAt(balle.position.x,balle.position.y,balle.position.z)
            groupe.rotateOnAxis(vecy,-Math.PI/phase2)//deuxième rotation du maillet
            phase2-=1
            reAffichage()
          }
          else{
            if(i>1 && i<2){
            balle.position.set(point2.x, point2.y, 0.5)//deuxieme mouvement de la balle
            i+=0.1;//vitesse de deplacement de la balle
            camera.position.y=20
            x=balle.position.x-10;
            camera.position.x=x;//repositionnement de la camera suivant la trajectoire de la balle
            camera.lookAt(balle.position.x,balle.position.y,balle.position.z)
            reAffichage()
            }
            else if(alea2==1) {
              if(phase3==11){//troisième phase de l'animation
                camera.position.x=0
                camera.position.y=50//deplacement de camera
                camera.lookAt(balle.position.x,balle.position.y,balle.position.z)
                groupe.position.set(balle.position.x+1,balle.position.y-2.5,balle.position.z+1.5)//changement de place du maillet
                groupe.rotateOnAxis(vecy,Math.PI/2)
                phase3=10;
                reAffichage();
              }
              else{
                if(phase3>=7){
                camera.position.x=0//fixer la camera
                camera.position.y=50
                camera.lookAt(balle.position.x,balle.position.y,balle.position.z)
                groupe.rotateOnAxis(vecy,-Math.PI/phase3)//troisième rotation du maillet
                phase3-=1
                reAffichage()
                }
                else{
                  if(j<=100){//troisième mouvement de la balle
                    balle.position.set(point3.x,point3.y, 0.5)
                    camera.position.x=11;//repositionnement de la camera suivant la trajectoire de la balle
                    y=balle.position.y+10;
                    camera.position.y=y
                    camera.lookAt(balle.position.x,balle.position.y,balle.position.z)
                    j+=10;//vitesse de la balle
                    reAffichage();
                   }
                   else if(alea3==1){
                    if(i>=2&&i<=3){//dernier mouvement de la balle
                      balle.position.set(point4.x,point4.y, 0.5)
                      i+=0.2;//vitesse de la balle
                      reAffichage();
                    }
                    else{
                      balle.position.set(pointfinal.x,pointfinal.y, 0.5)
                      reAffichage();
                    }
                  }
                }
              }
            }

          }
        }
      }
      else{
        //camera.lookAt(0,0,0)
        reAffichage();
      }
      }

     }, 200);// fin setTimeout(function ()
       // render avec requestAnimationFrame
     rendu.render(scene, camera);
    }// fin fonction reAffichage()
    
    
     function renduAnim() {
       stats.update();
       // render avec requestAnimationFrame
       requestAnimationFrame(renduAnim);
   // ajoute le rendu dans l'element HTML
       rendu.render(scene, camera);
     }
    
   } // fin fonction init()



   



   function BezDeg2(P0, P1, P2, nbPts,nbPts2,Phong){
    //creation d'une courbe de bezier de degrée 2
    let cbeBez = new THREE.QuadraticBezierCurve(P0, P1, P2 );
    //recuperation des points de la courbes
    let tab =cbeBez.getPoints(nbPts2);
    //creation d'une lathe avec les points de la courbes
    let cbeGeometry = new THREE.LatheGeometry(tab,nbPts, 2*Math.PI, 2*Math.PI);
    // Courbe avec les proprietes geometriques et l’aspect
    let CbeBezier2= new THREE.Mesh( cbeGeometry, Phong);
    //Renvoi de la courbe pour une utilisation ulterieure
    return CbeBezier2
    }

    function courbedeg2(P0, P1, P2, nbPts){
      //creation d'une courbe de bezier de degrée 2
      let courbe = new THREE.QuadraticBezierCurve(P0, P1, P2 );
      //recuperation des points de la courbes
      let tableau= courbe.getPoints(nbPts)
      //propietes geometrique de la courbe
      let courbeGeometry1 = new THREE.BufferGeometry().setFromPoints(tableau);
      //aspect de la courbe
      let courbematerial1 = new THREE.LineBasicMaterial( 
        { color : '#7F00FF' , 
          linewidth: 0.5    
        } )
        // Courbe avec les proprietes geometriques et l’aspect
        let courbe1 = new THREE.Line( courbeGeometry1, courbematerial1 );
        //renvoie la courbe
        return (courbe1);  
    }

    function courbedeg3(P0, P1, P2,P3, nbPts){
      //creation d'une courbe de bezier de degrée 3
      let courbe = new THREE.CubicBezierCurve3(P0, P1, P2, P3);
      //recuperation des points de la courbes
      let tableau= courbe.getPoints(nbPts)
      //propietes geometrique de la courbe
      let courbeGeometry2 = new THREE.BufferGeometry().setFromPoints(tableau);
      //aspect de la courbe
      let courbematerial2 = new THREE.LineBasicMaterial( 
        { color : '#7F00FF' , 
          linewidth: 0.5    
        } )
        // Courbe avec les proprietes geometriques et l’aspect
        let courbe1 = new THREE.Line( courbeGeometry2, courbematerial2 );
        //renvoie la courbe
        return (courbe1);  
    }


    function BezDeg3(P0, P1, P2,P3, nbPts,nbPts2,Phong){
      //creation d'une courbe de bezier de degrée 3
      let cbeBezdeg3=new THREE.CubicBezierCurve3(P0, P1, P2, P3);
      //recuperation des points de la courbes
      let tab2=cbeBezdeg3.getPoints(nbPts2)
      //creation d'une lathe avec les points de la courbes
      let cbeGeometry = new THREE.LatheGeometry(tab2,nbPts, 2*Math.PI, 2*Math.PI);
      // Points de la courbe de Bezier
      // Courbe avec les proprietes geometriques et l’aspect
      let CbeBezier2= new THREE.Mesh( cbeGeometry, Phong);
      //Renvoi de la courbe pour une utilisation ulterieure
      return CbeBezier2
      }
  
      
    function arceaux(nbPts1,nbPts2,nbPts3,nbPts4,nbPts5,nbPts6,P1,Q1,R1,c1,c2,x,y,Phong1,Phong2){
        let vecz= new THREE.Vector3(0,0,1);//axe de rotation
        let vecx= new THREE.Vector3(1,0,0);
        let vecy= new THREE.Vector3(0,1,0);
    
        let groupe=new THREE.Group()
  
        //points invariant des lathes
        let sol= new THREE.Vector3(1,0,0);
        let P0 = new THREE.Vector3(0.5,0,0);
        let R0 = new THREE.Vector3(0.5,4.5,0);
        //jointure G1 des lathes
        let A1= new THREE.Vector3(P1.x-Q1.x,P1.y-Q1.y,P1.z-Q1.z);
        let Z1= new THREE.Vector3(Q1.x+((A1.x)*c1),Q1.y+((A1.y)*c1),Q1.z+((A1.z)*c1));
        let A2= new THREE.Vector3(Q1.x-R1.x,Q1.y-R1.y,Q1.z-R1.z);
        let Z2= new THREE.Vector3(R1.x+((A2.x)*c2),R1.y+((A2.y)*c2),R1.z+((A2.z)*c2));
        //creation des lathes
        let C1=BezDeg3(sol,P0,P1,Z1,nbPts1,nbPts4,Phong1);//lathe1
        let C2=BezDeg2(Z1,Q1,Z2,nbPts2,nbPts5,Phong1);//lathe2
        let C3=BezDeg2(Z2,R1,R0,nbPts3,nbPts6,Phong1);//lathe3
        //deplacements des lathes
        C1.translateX(x)
        C1.translateY(y)
        C2.translateX(x)
        C2.translateY(y)
        C3.translateX(x)
        C3.translateY(y)
        C1.rotateOnAxis(vecx,Math.PI/2);
        C2.rotateOnAxis(vecx,Math.PI/2);
        C3.rotateOnAxis(vecx,Math.PI/2);
        //ajout dans groupe
        groupe.add(C1);
        groupe.add(C2);
        groupe.add(C3);
        
    
        //creation du deuxième plilier par clonage
        let T1=C1.clone();
        T1.geometry = C1.geometry
        T1.material = C1.material
        let T2=C2.clone();
        T2.geometry = C2.geometry
        T2.material = C2.material
        let T3=C3.clone();
        T3.geometry = C3.geometry
        T3.material = C3.material
        T1.translateX(5);
        T2.translateX(5);
        T3.translateX(5);
        //ajout du deuxieme pilier dans le groupe
        groupe.add(T1);
        groupe.add(T2);
        groupe.add(T3);
        
        //creation du cylindre horizontale
        //propriétés du cylindre
        let rayon1 = 0.5 ;
        let rayon2 = 0.5 ;
        let hauteur = 3 ;
        let nbePtsCercle = 60 ;
        let nbePtsGenera = 2 ;
        let bolOuvert = true ;
        let theta0 = 0 ;
        let thetaLg = 2*Math.PI ;
        let CylConeGeom = new THREE.CylinderGeometry(rayon1,rayon2,hauteur,nbePtsCercle, nbePtsGenera, bolOuvert,theta0, thetaLg );
        let cylindre = new THREE.Mesh(CylConeGeom ,Phong2);
        //deplacement du cylindre
        cylindre.translateX(2.5+x)
        cylindre.translateZ(5.5)
        cylindre.translateY(y)
        cylindre.rotateOnAxis(vecz,Math.PI/2);
        //ajout du cylindre dans groupe
        groupe.add(cylindre);
        
        //création du tore
        //propriétés du tore
        let R=1;
        let r=0.5;
        let nbePtsMeridien = 30 ;
        let nbePtsParallele = 60 ;
        let LgArc = Math.PI/2;
        let ToreGeom = new THREE.TorusGeometry (R,r,nbePtsMeridien , nbePtsParallele, LgArc );
        let tore1 = new THREE.Mesh(ToreGeom,Phong2 );
        //deplacement du tore
        tore1.translateX(4+x)
        tore1.translateZ(4.5)
        tore1.translateY(y)
        tore1.rotateOnAxis(vecx,Math.PI/2)
        //ajout du premier tore dans groupe
        groupe.add(tore1);
         
        //clonage du tore
        let tore2=tore1.clone();
        tore2.geometry=tore1.geometry;
        tore2.material=Phong2
        tore2.translateX(-3)
        tore2.rotateOnAxis(vecy,Math.PI)
        //ajout du deuxième tore dans groupe
        groupe.add(tore2);
        //renvoie de groupe
        return groupe
          }

    function prisme(h,r,n=3){
      let i;
      //creation de la géometrie
      let faceT = new THREE.Geometry();
        for( i=0;i<n;i++){
            let x1=Math.cos(i/n*2*Math.PI)*r;
            let y1=Math.sin(i/n*2*Math.PI)*r;
            let PtA = new THREE.Vector3 (x1,y1,0 );//sommet qui va composer le prisme
            let PtB = new THREE.Vector3 (x1,y1,h );//sommet alligné à PtA
            faceT.vertices.push(PtA, PtB);//sommet des deux points
        }
        let PtA = new THREE.Vector3 (0,0,0 );//centre du prisme
        let PtB = new THREE.Vector3 (0,0,h ); 
        faceT.vertices.push(PtA, PtB);
        for(i=0;i<n;i++){
          //creation des faces des cotés du prisme
          if(i==n-1){//derniére face
            faceT.faces.push(    
            new THREE.Face3 ( i*2, (i*2)+1, 0 ), //construction des faces
            new THREE.Face3 ( 0,(i*2)+1 ,1  ) 
            );    
        }
        else{
            faceT.faces.push(
                new THREE.Face3 ( i*2, (i*2)+1, (i*2)+2 ), 
                new THREE.Face3 ( (i*2)+2,(i*2)+1 ,(i*2)+3  ) 
            );
        }
        //fin creation des faces des cotés du prisme
        // creation des faces des sommets du prisme
        if(n%2==0){
          if(i==n-1){
          faceT.faces.push(    
            new THREE.Face3 ( i*2, n, 0 ), 
            new THREE.Face3 ( (i*2)+1,n+1 ,1  ) 
          );    
        }
        else{
          faceT.faces.push(
            new THREE.Face3 ( i*2, n, (i*2)+2 ), 
            new THREE.Face3 ( (i*2)+1, n+1, (i*2)+3  ) 
          );
        }
      }
      else{
          if(i==n-1){
            faceT.faces.push(    
              new THREE.Face3 ( i*2, n+1, 0 ), 
              new THREE.Face3 ( (i*2)+1,n ,1  ) 
            );    
            }
            else{
            faceT.faces.push(
              new THREE.Face3 ( i*2, n+1, (i*2)+2 ), 
              new THREE.Face3 ( (i*2)+1, n, (i*2)+3  ) 
            );
          }
        }
        }
        //fin creation des faces des sommets du prisme
        faceT.computeFaceNormals();//calcule de la normale de chaque face
        faceT.computeVertexNormals();//calcule de la normale de chaques sommet
        //creation du materiel
        let MaterialPhong = new THREE.MeshPhongMaterial({
          color: "#008B8B", // cyan fonce
            opacity: 1,
            transparent: false,
            emissive:0x000000, //couleur emissive
            specular:"#00FFFF", //couleur speculaire
            flatShading: false,
            shininess:30,//brillance
            side: THREE.DoubleSide,
          //
          
          });
          //objet avec la propriété geometrique et materiel
          let faceQuad1 = new THREE.Mesh( faceT, MaterialPhong );
          //renvoie de l'objet
          return faceQuad1;
           } 

         
                 

